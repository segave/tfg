package RED

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.util.CollectionAccumulator
import org.apache.spark.util.DoubleAccumulator
import scala.util.Random
import java.io._
import scala.io.Source

import org.apache.spark.util.CollectionAccumulator

import scala.math._
import java.time._
import java.time.format.DateTimeFormatter
import scala.collection.mutable.ListBuffer
import scala.util.Random

/**
 * @author ${user.name}
 */


object App {

  val conf = new SparkConf()
    .setAppName("PSO Distribuido")
    //.setMaster("local[*]")
    .set("spark.eventLog.dir", "/home/sergio/Escritorio/TFG/Spark/spark-3.5.0-bin-hadoop3/logs")
    .set("spark.eventLog.enabled", "true")
    .setJars(Array("/home/sergio/Escritorio/TFG/IdeaProjects/fumador_DSPSO/target/scala-2.12/fumador_dspso_2.12-0.1.0-SNAPSHOT.jar"))
    .setMaster("spark://localhost:7077")
    .set("spark.executor.resource.gpu.amount", "1")
    .set("spark.executor.resource.gpu.discoveryScript", "/opt/sparkRapidsPlugin/getGpusResources.sh")
  val sc = SparkContext.getOrCreate(conf)

  var particulas = Array.empty[Array[Double]]
  var mejor_pos_global = Array.empty[Double]
  var best_global_fitness = Double.MaxValue

  val rand = new Random

  val pos_max = 1.0

  val W = 1.0
  val c1 = 3.5
  val c2 = 1.8
  val V_max = 0.1*pos_max
  val I = 10
  val m = 100

  // Función de activación ReLU
  def relu(x: Double): Double = Math.max(0, x)

  // Función de activación Sigmoide
  def sigmoid(x: Double): Double = 1.0 / (1.0 + Math.exp(-x))

  def signo_umbral(number: Double, umbral: Double): Double = {
    var resultado: Double = 0.5
    if (number < umbral) {
      resultado = 0.0
    } else {
      resultado = 1.0
    }
    resultado
  }

  // Calcula wT*x(i) (Valor predicho para el dato x(i))
  def h(x: Array[Array[Double]], w: Array[Double], i: Int): Double = {
    var sum = 0.0
    for (j <- x(i).indices) {
      sum += x(i)(j) * w(j)
    }
    sum
  }

  def forwardProp(x: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    val z2 = Array.fill(nHidden)(0.0)
    //Paso de capa inicial a oculta
    for (j <- 0 until nHidden) {
      val weights1 = weights.slice(nInputs * j, nInputs * (j + 1))
      var resultado = 0.0
      for (k <- 0 until nInputs) {
        resultado += x(k) * weights1(k)
      }
      z2(j) = resultado
    }
    //paso de la capa de neuronas ocultas a la de salida
    var z3 = 0.0
    val weights2 = weights.slice(nInputs * nHidden, weights.length)
    for (k <- 0 until nHidden) {
      z3 += z2(k) * weights2(k)
    }
    z3 //no se aplica la tanh en la capa de salida
  }

  def forwardPropClas(x: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    val z2 = Array.fill(nHidden)(0.0)

    // Paso de capa inicial a oculta
    for (j <- 0 until nHidden) {
      val weights1 = weights.slice(nInputs * j, nInputs * (j + 1))
      var resultado = 0.0
      for (k <- 0 until nInputs) {
        resultado += x(k) * weights1(k)
      }
      z2(j) = relu(resultado)
    }

    // Paso de capa oculta a la salida
    var z3 = 0.0
    val weights2 = weights.slice(nInputs * nHidden, weights.length)
    for (k <- 0 until nHidden) {
      z3 += z2(k) * weights2(k)
    }

    // Aplicamos la tangente hiperbólica en la capa de salida (función identidad)
    val z4 = sigmoid(z3)
    z4
  }

  def calculateAccuracy(yTrue: Array[Double], yPred: Array[Double]): Double = {
    require(yTrue.length == yPred.length, "Las listas deben tener la misma longitud")

    val totalSamples = yTrue.length
    val correctPredictions = yTrue.zip(yPred).count { case (trueLabel, predictedLabel) => trueLabel == predictedLabel }


    val resultado = correctPredictions.toDouble / totalSamples

    //println("resultado accuracy en calculateAccuracy: " + resultado)

    resultado

  }

  def binaryCrossEntropy(yTrue: Array[Double], yPred: Array[Double]): Double = {
    require(yTrue.length == yPred.length, "Las listas deben tener la misma longitud")

    val epsilon = 1e-15 // Pequeña constante para evitar divisiones por cero
    val clippedYPred = yPred.map(p => Math.max(epsilon, Math.min(1 - epsilon, p))) // Clip para evitar log(0) y log(1)

    val loss = -yTrue.zip(clippedYPred).map { case (trueLabel, predLabel) =>
      trueLabel * Math.log(predLabel) + (1 - trueLabel) * Math.log(1 - predLabel)
    }.sum

    loss
  }

  def binaryEntropyRed(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    val n_datos = x.length

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until n_datos) {
      val pr = forwardPropClas(x(i), weights, nInputs, nHidden)
      yPred = yPred :+ pr
    }
    resultado = binaryCrossEntropy(y, yPred)
    resultado

  }

  def MSERed(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    val n_datos = x.length

    for (i <- 0 until n_datos) {
      val pred = forwardProp(x(i), weights, nInputs, nHidden)
      resultado += math.pow(y(i) - pred, 2)
    }
    resultado /= n_datos
    resultado

  }


  def convertToDayOfWeek(dates: List[String]): List[String] = {
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    dates.map { dateStr =>
      val date = LocalDate.parse(dateStr, formatter)
      val dayOfWeek = date.getDayOfWeek.toString
      dayOfWeek
    }
  }

  def separateHourMinute(hourColumn: List[String]): (List[String], List[String]) = {
    val (hours, minutes) = hourColumn.map { hourStr =>
      val parts = hourStr.split(":")
      (parts(0), parts(1))
    }.unzip

    (hours, minutes)
  }

  def separateDayHourMinuteSecond(dates: List[String]): (List[String], List[String]) = {
    val (days, hours) = dates.map { hourStr =>
      val parts = hourStr.split(" ")
      (parts(0), parts(1))
    }.unzip

    (days, hours)
  }

  def encode[T](values: List[T]): List[List[Double]] = {
    val uniqueValues = values.distinct
    val numValues = uniqueValues.length
    val numSamples = values.length

    values.map { value =>
      val index = uniqueValues.indexOf(value)
      List.tabulate(numValues)(i => if (i == index) 1.0 else 0.0)
    }
  }

  //Genera un uniform entre -a y a
  def Uniform(a: Double, rand: Random): Double = {
    val num = rand.nextDouble() * 2 * a // genera un número aleatorio entre 0.0 y 2a
    val ret = num - a
    ret
  }

  def fitnessEval(x: Array[Array[Double]], y: Array[Double], particula_pesos: Array[Double], nInputs: Int, nHidden: Int): Array[Double] = {

    val nWeights: Int = nHidden * (nInputs + 1)
    //Voy a usar dos capas ocultas
    //val nWeights: Int =nHidden*(nInputs + nHidden + 1)

    if (particula_pesos == null) {
      println("El array de pesos es null")
      return Array.empty[Double]
    }

    val best_fit_local = particula_pesos(3 * nWeights)
    val weights = particula_pesos.slice(0, nWeights)
    //val fit = MSERed(x, y, weights, nInputs, nHidden)
    //val fit = AccuracyRed(x, y, weights, nInputs, nHidden, umbral)
    //val fit = f1Red(x, y, weights, nInputs, nHidden)
    //val fit = aucRed(x, y, weights, nInputs, nHidden)
    val fit = binaryEntropyRed(x, y, weights, nInputs, nHidden)

    //println("fit " + fit)

    if (fit < best_fit_local) {
      particula_pesos(3 * nWeights) = fit
      for (k <- 0 until nWeights) {
        particula_pesos(2 * nWeights + k) = weights(k)
      }

    }
    particula_pesos
  }

  def posEval(part: Array[Double], mpg: Array[Double], N: Int, rand: Random, W: Double, c_1: Double, c_2: Double, V_max: Double, pos_max: Double): Array[Double] = {
    // global ind (no es necesario en Scala)
    val velocidades = part.slice(N, 2 * N)
    val mpl = part.slice(2 * N, 3 * N)
    val r_1 = rand.nextDouble()
    val r_2 = rand.nextDouble()
    for (k <- 0 until N) {
      velocidades(k) = W * velocidades(k) + c_1 * r_1 * (mpl(k) - part(k)) + c_2 * r_2 * (mpg(k) - part(k))
      if (velocidades(k) > V_max) {
        velocidades(k) = V_max
      } else if (velocidades(k) < -V_max) {
        velocidades(k) = -V_max
      }
      part(k) = part(k) + velocidades(k)
      if (part(k) > pos_max) {
        part(k) = pos_max
      } else if (part(k) < -pos_max) {
        part(k) = -pos_max
      }
      part(N + k) = velocidades(k)
    }
    part
  }

  // Convertir el Array[Array[Double]] a un ListBuffer[Array[Double]]
  def toListBuffer(arrayArray: Array[Array[Double]]): ListBuffer[Array[Double]] = {
    val listBuffer: ListBuffer[Array[Double]] = ListBuffer.empty[Array[Double]]

    // Recorrer cada subarray en el Array[Array[Double]] y convertirlo a un List[Double]
    for (subArray <- arrayArray) {
      val list: List[Double] = subArray.toList
      // Agregar el List[Double] al ListBuffer[Array[Double]]
      listBuffer += list.toArray
    }

    listBuffer
  }

  def accuracyOfDataset(archivo_val: String, weights: Array[Double], nInputs: Int, nHidden: Int, takeRows: Boolean, numRowsToKeep: Int): Double = {

    var dataRows = Source.fromFile(archivo_val).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dataListString: List[Array[String]] = dataRows.map(_.take(68))
    //val dataTest: List[Array[Double]] = dataListStringTest.map(_.map(_.toDouble))
    var valorStringTest = dataRows.map(_(68))
    var valor: List[Double] = valorStringTest.map {
      case "0" => 0.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    //var data = encodeFumador(dataListString)

    var data = dataListString.map(_.map(_.toDouble))

    if (takeRows) {
      data = data.take(numRowsToKeep)
      valor = valor.take(numRowsToKeep)
    }

    val x = data.toArray
    val y = valor.toArray

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until x.length) {
      val pr = signo_umbral(forwardPropClas(x(i), weights, nInputs, nHidden), 0.5)
      yPred = yPred :+ pr
    }

    val resultado = 1.0 - calculateAccuracy(y, yPred)
    resultado
  }

  def modifyAccum(part: Array[Double], N: Int, local_accum_pos: CollectionAccumulator[Array[Double]], local_accum_fit: CollectionAccumulator[Double]): Unit = {
    local_accum_pos.add((part.slice(2 * N, 3 * N)))
    local_accum_fit.add(part(3 * N))
  }

  def main(args: Array[String]): Unit = {
    //Archivos para las gráficas
    val fileNameTraining = "/home/sergio/Escritorio/TFG/datos_fumador/training_feature.csv"
    val fileNameTest = "/home/sergio/Escritorio/TFG/datos_fumador/test_feature.csv"
    val numRowsToKeep: Int = 3000 // Número de filas que deseas mantener

    var dataRows = Source.fromFile(fileNameTraining).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    /*var dataRows = Source.fromFile(fileNameTraining).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }*/
    val dataListString: List[Array[String]] = dataRows.map(_.take(68))
    var valorString = dataRows.map(_(68))
    val valor: List[Double] = valorString.map {
      case "0" => 0.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    //dataRows.foreach(row => println(row.mkString(", ")))

    val filas = dataRows.length
    val columnas = if (filas > 0) dataRows.head.length else 0

    println(s"El número de filas es: $filas")
    println(s"El número de columnas es: $columnas")

    //Lo mismo para test
    var dataRowsTest = Source.fromFile(fileNameTest).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dataListStringTest: List[Array[String]] = dataRowsTest.map(_.take(68))
    //val dataTest: List[Array[Double]] = dataListStringTest.map(_.map(_.toDouble))
    var valorStringTest = dataRowsTest.map(_(68))
    val valorTest: List[Double] = valorStringTest.map {
      case "0" => 0.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    val data = dataListString.map(_.map(_.toDouble))
    val dataTest = dataListStringTest.map(_.map(_.toDouble))


    //número de características
    val nInputs: Int = data.headOption.map(_.length).getOrElse(0)
    //número de neuronas en la capa oculta
    val nHidden: Int = (1.9 * nInputs).toInt
    val nWeights: Int = nHidden * (nInputs + 1)

    //val existingFile = new FileWriter(s"resultados_sonar_DAPSO_$iters _$parts _$v_max.txt", true)
    val existingFile = new FileWriter(s"resultados_fumador_$I _$m _$pos_max _$c1 _$c2.txt", true)
    val outputFile = new PrintWriter(existingFile)

    particulas = Array.empty[Array[Double]]
    mejor_pos_global = Array.empty[Double]
    best_global_fitness = Double.MaxValue

    val xSer: Array[Array[Double]] = data.toArray
    val ySer: Array[Double] = valor.toArray

    for (i <- 0 until m) {
      val posicion = Array.fill(nWeights)(Uniform(pos_max, rand))
      val velocidad = Array.fill(nWeights)(Uniform(pos_max, rand))
      val fit = binaryEntropyRed(xSer, ySer, posicion, nInputs, nHidden)
      val part_ = posicion ++ velocidad ++ posicion ++ Array(fit)
      if (fit < best_global_fitness) {
        best_global_fitness = fit
        mejor_pos_global = posicion
      }
      particulas = particulas :+ part_
    }

    val start = System.nanoTime()
    var rdd_master = sc.parallelize(particulas)

    for (i <- 0 until I) {
      println("iteracion: " + i)
      val local_accum_pos: CollectionAccumulator[Array[Double]] = sc.collectionAccumulator[Array[Double]]("MejorPosLocales")
      //val local_accum_fit: DoubleAccumulator = sc.doubleAccumulator("MiAcumulador")
      val local_accum_fit: CollectionAccumulator[Double] = sc.collectionAccumulator[Double]("MejorFitLocales")
      val rdd_fitness = rdd_master.map(part => fitnessEval(xSer, ySer, part, nInputs, nHidden))
      rdd_fitness.foreach(part => modifyAccum(part, nWeights, local_accum_pos, local_accum_fit))
      rdd_fitness.collect().foreach(part => modifyAccum(part, nWeights, local_accum_pos, local_accum_fit))

      val blfs = local_accum_fit.value
      //Intento resolver error
      //val auxError = rdd_fitness.collect()
      for (j <- 0 until m) {
        val blf = blfs.get(j)
        //val blf = auxError(j)(3 * nWeights)
        if (blf < best_global_fitness) {
          best_global_fitness = blf
          mejor_pos_global = local_accum_pos.value.get(j)
          //mejor_pos_global = auxError(j).slice(2 * nWeights, 3 * nWeights)
        }
      }
      val resultado2 = rdd_fitness.map(part => posEval(part, mejor_pos_global, nWeights, rand, W, c1, c2, V_max, pos_max))
      val resultado_collected = resultado2.collect()
      rdd_master = sc.parallelize(resultado_collected)
    }

    val end = System.nanoTime()
    val duration = (end - start) / 1e9

    val weights = mejor_pos_global

    var predicha: List[Double] = List()
    for (i <- 0 until dataTest.length) {
      val prDouble = forwardPropClas(dataTest(i), weights, nInputs, nHidden)
      val pr = signo_umbral(prDouble, 0.5)
      predicha = predicha :+ pr
    }

    for ((real, predicho) <- valorTest.zip(predicha)) {
      //println(s"Real: $real - Predicho: $predicho")
      outputFile.println(s"$real,$predicho")
    }

    val unosReales = valorTest.count(_ == 1)
    val unosPredichos = predicha.count(_ == 1)

    println(s"La cantidad de unos reales es: $unosReales")
    println(s"La cantidad de unos predichos es: $unosPredichos")

    println("Resultados con pos_max: " + pos_max + ", c_1: " + c1 + ", c_2: " + c2 + ":")

    val error_out_test = accuracyOfDataset(fileNameTest, weights, nInputs, nHidden, false, numRowsToKeep)
    val error_in = accuracyOfDataset(fileNameTraining, weights, nInputs, nHidden, true, numRowsToKeep)

    println("Ein accuracy: " + error_in)
    println("Eout accuracy: " + error_out_test)

    outputFile.close()
    //println(s"$I,$m")

    // Imprimir la duración en segundos
    println(s"El programa tardó $duration segundos.")
  }
}


