import com.twitter.chill.KryoSerializer
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
object ScalaSparkExample {
  class MyData2(val myData2: String) {
    override def toString: String = s"MyData2{myData2=$myData2}"
  }
  var zeroMyData: MyData2 = _

  def main(args: Array[String]): Unit = {
    val master = if (args.length == 0) "local[*]" else args(0)
    val sparkConf = new SparkConf().setAppName(this.getClass.getName).setMaster(master)
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    val sparkContext = new SparkContext(sparkConf)
    val ints: Seq[Int] = Seq(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    val strings: Seq[String] = ints.map(i => i.toString)
    println("strings: "+strings, "length: "+strings.length, "fourth element: "+strings(3))
    val stringsRDD: RDD[String] = sparkContext.parallelize(strings)
    zeroMyData = new MyData2("0")
    val myDatasRDD: RDD[MyData2] = stringsRDD.map(s => new MyData2((zeroMyData.myData2.toInt + s.toInt).toString))
    println("myDatasRDD: "+myDatasRDD.toString(),"length: "+myDatasRDD.toString().length, "fourth element: "+(myDatasRDD.toString())(3))
    val aggregatedMyData2 = myDatasRDD.reduce((y1, y2) => new MyData2((y1.myData2.toInt + y2.myData2.toInt).toString))
    var len= aggregatedMyData2.toString().length()
    println(aggregatedMyData2.toString(), "length: "+len)

  }

}
