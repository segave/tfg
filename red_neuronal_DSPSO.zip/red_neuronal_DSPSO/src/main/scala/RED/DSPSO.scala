package RED

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.util.CollectionAccumulator
import org.apache.spark.util.DoubleAccumulator
import scala.util.Random
import java.io._
import scala.io.Source

import org.apache.spark.util.CollectionAccumulator

import scala.math._
import java.time._
import java.time.format.DateTimeFormatter
import scala.collection.mutable.ListBuffer
import scala.util.Random

/**
 * @author ${user.name}
 */


object App {

  val conf = new SparkConf()
    .setAppName("PSO Distribuido")
    .setMaster("local[*]")
  val sc = SparkContext.getOrCreate(conf)

  // Número de partículas
  val m = 100
  // Número de iteraciones
  val I = 10000

  var particulas = Array.empty[Array[Double]]
  var mejor_pos_global = Array.empty[Double]
  var best_global_fitness = Double.MaxValue

  val rand = new Random

  val W = 1.0
  val c_1 = 0.8
  val c_2 = 0.2
  val V_max = 10.0

  // Calcula wT*x(i) (Valor predicho para el dato x(i))
  def h(x: Array[Array[Double]], w: Array[Double], i: Int): Double = {
    var sum = 0.0
    for (j <- x(i).indices) {
      sum += x(i)(j) * w(j)
    }
    sum
  }

  def forwardProp(x: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    val z2 = Array.fill(nHidden)(0.0)

    // Paso de capa inicial a oculta
    for (j <- 0 until nHidden) {
      val weights1 = weights.slice(nInputs * j, nInputs * (j + 1))
      //println(s"longitud de x: ${x.length} - longitud de pesos: ${weights1.length}")
      var resultado = 0.0
      for (k <- 0 until nInputs) {
        resultado += x(k) * weights1(k)
      }
      z2(j) = tanh(resultado)
    }

    // Paso de capa oculta a la salida
    var z3 = 0.0
    val weights2 = weights.slice(nInputs * nHidden, weights.length)
    for (k <- 0 until nHidden) {
      z3 += z2(k) * weights2(k)
    }

    // No aplicamos la tangente hiperbólica en la capa de salida (función identidad)
    z3
  }

  def MSERed(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    val n_datos = x.length

    for (i <- 0 until n_datos) {
      val pred = forwardProp(x(i), weights, nInputs, nHidden)
      resultado += math.pow(y(i) - pred, 2)
    }
    resultado /= n_datos
    resultado

  }


  def convertToDayOfWeek(dates: List[String]): List[String] = {
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    dates.map { dateStr =>
      val date = LocalDate.parse(dateStr, formatter)
      val dayOfWeek = date.getDayOfWeek.toString
      dayOfWeek
    }
  }

  def separateHourMinute(hourColumn: List[String]): (List[String], List[String]) = {
    val (hours, minutes) = hourColumn.map { hourStr =>
      val parts = hourStr.split(":")
      (parts(0), parts(1))
    }.unzip

    (hours, minutes)
  }

  def encode[T](values: List[T]): List[List[Double]] = {
    val uniqueValues = values.distinct
    val numValues = uniqueValues.length
    val numSamples = values.length

    values.map { value =>
      val index = uniqueValues.indexOf(value)
      List.tabulate(numValues)(i => if (i == index) 1.0 else 0.0)
    }
  }

  //Genera un uniform entre -a y a
  def Uniform(a: Double, rand: Random): Double = {
    val num = rand.nextDouble() * 2 * a // genera un número aleatorio entre 0.0 y 2a
    val ret = num - a
    ret
  }

  def fitnessEval(x: Array[Array[Double]], y: Array[Double], particula_pesos: Array[Double], nInputs: Int, nHidden: Int): Array[Double] = {

    val nWeights: Int = nInputs * (nHidden + 1)

    if (particula_pesos == null) {
      println("El array de pesos es null")
      return Array.empty[Double]
    }

    val best_fit_local = particula_pesos(3 * nWeights)
    val weights = particula_pesos.slice(0, nWeights)
    val fit = MSERed(x, y, weights, nInputs, nHidden)
    if (fit < best_fit_local) {
      particula_pesos(3 * nWeights) = fit
      for (k <- 0 until nWeights) {
        particula_pesos(2 * nWeights + k) = weights(k)
      }

    }
    particula_pesos
  }

  def posEval(part: Array[Double], mpg: Array[Double], N: Int, rand: Random, W: Double, c_1: Double, c_2: Double, V_max: Double): Array[Double] = {
    // global ind (no es necesario en Scala)
    val velocidades = part.slice(N, 2 * N)
    val mpl = part.slice(2 * N, 3 * N)
    val r_1 = rand.nextDouble()
    val r_2 = rand.nextDouble()
    for (k <- 0 until N) {
      velocidades(k) = W * velocidades(k) + c_1 * r_1 * (mpl(k) - part(k)) + c_2 * r_2 * (mpg(k) - part(k))
      if (velocidades(k) > V_max) {
        velocidades(k) = V_max
      } else if (velocidades(k) < -V_max) {
        velocidades(k) = -V_max
      }
      part(k) = part(k) + velocidades(k)
      part(N + k) = velocidades(k)
    }
    part
  }

  def modifyAccum(part: Array[Double], N: Int, local_accum_pos: CollectionAccumulator[Array[Double]], local_accum_fit: CollectionAccumulator[Double]): Unit = {
    local_accum_pos.add((part.slice(2 * N, 3 * N)))
    local_accum_fit.add(part(3 * N))
  }

  def main(args: Array[String]): Unit = {
    val fileName = "C:/Users/jorge/Desktop/TFG/REE 2007-2019 David (Preprocesado 2009-2019)/demanda_limpia_final.csv"

    val numRowsToKeep: Int = 500 // Número de filas que deseas mantener

    var dataRows = Source.fromFile(fileName).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }

    // Acceder a las columnas individualmente
    var dates = dataRows.map(_(5))
    var hourColumn = dataRows.map(_(0))
    var potProgramadaString = dataRows.map(_(3))
    var potRealString = dataRows.map(_(1))

    println(potProgramadaString.mkString(", "))


    val potProgramada = potProgramadaString.map(_.toDouble)
    val potReal = potRealString.map(_.toDouble)


    var daysOfWeek = convertToDayOfWeek(dates)

    var (hours, minutes) = separateHourMinute(hourColumn)

    val oneHotHours = encode(hours)
    val oneHotMinutes = encode(minutes)
    val oneHotDays = encode(daysOfWeek)

    //Intentamos liberar memoria
    dataRows = null
    potProgramadaString = null
    dates = null
    hourColumn = null
    hours = null
    minutes = null
    daysOfWeek = null

    val combinedMatrix1 = oneHotDays.zip(oneHotHours).map { case (rowA, rowB) =>
      rowA ++ rowB
    }

    val numRowsCM1: Int = combinedMatrix1.length
    val numRowsOHM: Int = oneHotMinutes.length

    println(s"Número de filas CM1: $numRowsCM1")
    println(s"Número de filas OHM: $numRowsOHM")

    val combinedMatrix2 = combinedMatrix1.zip(oneHotMinutes).map { case (rowA, rowB) =>
      rowA ++ rowB
    }

    val dataList = combinedMatrix2.zip(potProgramada).map { case (row, value) =>
      row :+ value
    }

    val data: List[Array[Double]] = dataList.map(_.toArray)


    // Imprime la matriz combinada
    data.foreach(row => println(row.mkString(", ")))

    //número de características
    val nInputs: Int = data.headOption.map(_.size).getOrElse(0)

    //número de neuronas en la capa oculta
    val nHidden: Int = 4

    val nWeights: Int = nInputs * (nHidden + 1)

    // Número dimensiones de los pesos
    val n = nWeights

    // Convertir las listas a arrays serializables
    val xSer: Array[Array[Double]] = data.toArray
    val ySer: Array[Double] = potReal.toArray

    // Inicializamos los vectores
    for (i <- 0 until m) {

      //Aquí puede que sea mejor inicializar las últimas posiciones a valores más pequeños
      val posicion = Array.fill(nWeights)(Uniform(100, rand))
      val velocidad = Array.fill(nWeights)(Uniform(100, rand))
      val fit = MSERed(xSer, ySer, posicion, nInputs, nHidden)
      val part_ = posicion ++ velocidad ++ posicion ++ Array(fit)

      if (fit < best_global_fitness) {
        best_global_fitness = fit
        mejor_pos_global = posicion
      }
      particulas = particulas :+ part_
    }

    //procesamos
    var rdd_master = sc.parallelize(particulas)

    for (i <- 0 until I) {

      val local_accum_pos: CollectionAccumulator[Array[Double]] = sc.collectionAccumulator[Array[Double]]("MejorPosLocales")
      //val local_accum_fit: DoubleAccumulator = sc.doubleAccumulator("MiAcumulador")
      val local_accum_fit: CollectionAccumulator[Double] = sc.collectionAccumulator[Double]("MejorFitLocales")

      val rdd_fitness = rdd_master.map(part => fitnessEval(xSer, ySer, part, nInputs, nHidden))

      rdd_fitness.foreach(part => modifyAccum(part, nWeights, local_accum_pos, local_accum_fit))

      val blfs = local_accum_fit.value
      for (j <- 0 until m) {
        val blf = blfs.get(j)
        if (blf < best_global_fitness) {
          best_global_fitness = blf
          mejor_pos_global = local_accum_pos.value.get(j)
        }
      }

      val resultado2 = rdd_fitness.map(part => posEval(part, mejor_pos_global, nWeights, rand, W, c_1, c_2, V_max))

      val resultado_collected = resultado2.collect()

      rdd_master = sc.parallelize(resultado_collected)

    }
    println(s"mejor_pos_global-> ${mejor_pos_global.mkString("[", ", ", "]")}")
    println(s"mejor fitness global-> $best_global_fitness")

    val weights = mejor_pos_global

    var potPredicha: List[Double] = List()
    for (i <- 0 until data.length) {
      val pot = forwardProp(data(i), weights, nInputs, nHidden)

      potPredicha = potPredicha :+ pot
    }

    for ((real, predicho) <- potReal.zip(potPredicha)) {
      println(s"Potencia real: $real - Potencia predicha: $predicho")
    }


  }


}


