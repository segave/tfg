package splitter

import scala.io.Source
import java.io.PrintWriter
import scala.util.Random

object CSVSplitter {
  def main(args: Array[String]): Unit = {
    val inputFile = "C:/Users/jorge/Desktop/TFG/COVID19_mexico/mexico_covid19_Procesado.csv"
    val trainingFile = "covid_training.csv"
    val testFile = "covid_test.csv"
    val validationFile = "covid_validation.csv"
    val splitRatios = (0.60, 0.25, 0.15) // 60% training, 25% test, 15% validation

    val lines = Source.fromFile(inputFile).getLines().toList
    val header :: data = lines

    val (trainingData, testData, validationData) = splitDataByClass(data, splitRatios)

    // Aplica random shuffle a trainingData
    val shuffledTrainingData = Random.shuffle(trainingData)

    writeToFile(trainingFile, header :: shuffledTrainingData)
    writeToFile(testFile, header :: testData)
    writeToFile(validationFile, header :: validationData)

    println("CSV data split successfully!")
  }

  def splitDataByClass(data: List[String], splitRatios: (Double, Double, Double)): (List[String], List[String], List[String]) = {
    val classAData = data.filter(_.endsWith(",0"))
    val classBData = data.filter(_.endsWith(",1"))

    val classATrainingCount = (classAData.length * splitRatios._1).toInt
    val classBTrainingCount = (classBData.length * splitRatios._1).toInt

    val classATestCount = (classAData.length * splitRatios._2).toInt
    val classBTestCount = (classBData.length * splitRatios._2).toInt

    val trainingData = classAData.take(classATrainingCount) ++ classBData.take(classBTrainingCount)
    val testData = classAData.slice(classATrainingCount, classATrainingCount + classATestCount) ++
      classBData.slice(classBTrainingCount, classBTrainingCount + classBTestCount)
    val validationData = classAData.drop(classATrainingCount + classATestCount) ++
      classBData.drop(classBTrainingCount + classBTestCount)

    (trainingData, testData, validationData)
  }

  def writeToFile(filename: String, lines: List[String]): Unit = {
    val outputFile = new PrintWriter(filename)
    lines.foreach(outputFile.println)
    outputFile.close()
  }
}