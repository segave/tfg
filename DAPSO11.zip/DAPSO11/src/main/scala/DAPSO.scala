import akka.actor.typed.scaladsl.{ActorContext, Behaviors}
import akka.actor.typed.{ActorRef, Behavior, ActorSystem}

object DAPSO {
  object FitnessEvalActor {
    import GlobalEvalActor.SystemMessage
    sealed trait MessageToFitnessActor{
      def sender: ActorRef[SystemMessage]
    }
    final case class ContinueReceivingMessage (sender: ActorRef[SystemMessage]) extends MessageToFitnessActor

    def apply():Behavior[MessageToFitnessActor] = Behaviors.setup{
      context: ActorContext[MessageToFitnessActor] =>
        Behaviors.receiveMessage { message =>
          message match {
            case ContinueReceivingMessage(sender) =>
              println("Evaluando fitness")
              Behaviors.same
          }
        }
    }

  }

  object GlobalEvalActor{
    import FitnessEvalActor._
    sealed trait SystemMessage
    case object StartSendingMessages extends SystemMessage
    case object ContinueSendingMessages extends SystemMessage
    case object StopSendingMessages extends SystemMessage

    def apply(): Behavior[SystemMessage]= Behaviors.setup[SystemMessage]{
      actorContext=>
        val fitnessEvalActor= actorContext.spawn(FitnessEvalActor(),"FitnessEvalActor")
        Behaviors.receiveMessage{
          case StartSendingMessages=>
            println("Start Global Actor task")
            //Simula la llamada a aggregator.recibir(nueva_particula)
            Thread.sleep(1_000)
            fitnessEvalActor ! ContinueReceivingMessage(actorContext.self)
            Behaviors.same
          case StopSendingMessages=>
            println("Los resultados globales del cálculo!!!")
            Behaviors.stopped
        }
    }
  }
  def main(args: Array[String]): Unit = {
    import GlobalEvalActor.{StartSendingMessages, StopSendingMessages, SystemMessage}
    val actor: ActorSystem[SystemMessage]= ActorSystem(GlobalEvalActor(),"GlobalEvalActor" )
    actor ! StartSendingMessages
    Thread.sleep(1_000)
    actor ! StopSendingMessages
    Thread.sleep(500)
    actor.terminate()
    println("Se acabó!!!")
  }

}
