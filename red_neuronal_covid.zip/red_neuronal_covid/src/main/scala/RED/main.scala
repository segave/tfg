package RED

import RED.Funciones_Auxiliares

import java.io.{File, FileWriter, PrintWriter}
import scala.io.Source

object Main {

  val FA = new Funciones_Auxiliares

  def main(args: Array[String]): Unit = {
    val fileNameTraining = "C:/Users/jorge/Desktop/TFG/COVID19_mexico/resampled_data.csv"
    val fileNameTest = "C:/Users/jorge/Desktop/TFG/COVID19_mexico/covid_test.csv"
    val fileNameValidation = "C:/Users/jorge/Desktop/TFG/COVID19_mexico/covid_validation.csv"
    val numRowsToKeep: Int = 2080 // Número de filas que deseas mantener

    var dataRows = Source.fromFile(fileNameTraining).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.take (numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dataListString: List[Array[String]] = dataRows.map(_.take(23))
    val data: List[Array[Double]] = dataListString.map(_.map(_.toDouble))
    var valorString = dataRows.map(_(23))
    val valor: List[Double] = valorString.map {
      case "0" => -1.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    //Lo mismo para test
    var dataRowsTest = Source.fromFile(fileNameTest).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dataListStringTest: List[Array[String]] = dataRowsTest.map(_.take(23))
    val dataTest: List[Array[Double]] = dataListStringTest.map(_.map(_.toDouble))
    var valorStringTest = dataRowsTest.map(_(23))
    val valorTest: List[Double] = valorStringTest.map {
      case "0" => -1.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    //número de características
    val nInputs: Int = data.headOption.map(_.length).getOrElse(0)
    //número de neuronas en la capa oculta
    val nHidden: Int =  (1.9*nInputs).toInt
    val num_iteraciones = List(100)
    val num_particulas = List(100)
    val posiciones_max = List(1.0)
    val c_unos = List(0.4)
    val c_dos = List(0.2)

    val validationFile = new FileWriter(s"resultados_validacion.txt", true)
    val hiperparametersFile = new PrintWriter(validationFile)

    for (iters <- num_iteraciones) {
      for (parts <- num_particulas) {
        for (pos_max <- posiciones_max){
          for (c1 <- c_unos){
            for (c2 <- c_dos){
              //val existingFile = new FileWriter(s"resultados_sonar_DAPSO_$iters _$parts _$v_max.txt", true)
              val existingFile = new FileWriter(s"resultados_covid_secuencial_$iters _$parts _$pos_max.txt", true)
              val outputFile = new PrintWriter(existingFile)

              hiperparametersFile.println(s"resultados con c1 $c1, c2 $c2, posicion maxima $pos_max")

              //Ejecución de PSO secuencial
              val trainer = new pso_secuencial(data, valor, nInputs, nHidden, iters, parts, pos_max)

              //Ejecución de DAPSO
              //val trainer = new DAPSO(data, valor, nInputs, nHidden, parts, iters, v_max)
              trainer.inicializar_pesos()
              val start = System.nanoTime()
              trainer.procesar()
              val end = System.nanoTime()
              val weights = trainer.get_pesos()

              //comprobacion
              /*val particula: Array[Double] = weights ++ weights ++ weights ++ Array(0.0)
              val xSer: Array[Array[Double]] = data.toArray
              val ySer: Array[Double] = valor.toArray
              println("comp:")
              println(FA.fitnessEval(xSer, ySer, particula, nInputs, nHidden).mkString(", "))*/

              /*val tiempo = (end - start) / 1e9
              outputFile.println(s"$tiempo, 0")
              var predicha: List[Double] = List()
              for (i <- 0 until data.length) {
                val prDouble = FA.forwardPropClas(data(i), weights, nInputs, nHidden)
                val pr = math.signum(prDouble)
                predicha = predicha :+ pr
              }

              for ((real, predicho) <- valor.zip(predicha)) {
                println(s"Real: $real - Predicho: $predicho")
                outputFile.println(s"$real,$predicho")
              }*/

              var predicha: List[Double] = List()
              for (i <- 0 until dataTest.length) {
                val prDouble = FA.forwardPropClas(dataTest(i), weights, nInputs, nHidden)
                val pr = math.signum(prDouble)
                predicha = predicha :+ pr
              }

              for ((real, predicho) <- valorTest.zip(predicha)) {
                println(s"Real: $real - Predicho: $predicho")
                outputFile.println(s"$real,$predicho")
              }

              val unosReales = valorTest.count(_ == 1)
              val unosPredichos = predicha.count(_ == 1)

              println(s"La cantidad de unos reales es: $unosReales")
              println(s"La cantidad de unos predichos es: $unosPredichos")

              //validación

              println("Resultados de la validación con pos_max: " + pos_max + ", c_1: " + c1 + ", c_2: " + c2 + ":")

              val error_out_test = FA.accuracyOfDataset(fileNameTest, weights, nInputs, nHidden)
              val error_out_validation = FA.accuracyOfDataset(fileNameValidation, weights, nInputs, nHidden)

              val f1_out_test = FA.f1OfDataset(fileNameTest, weights, nInputs, nHidden)
              val f1_out_validation = FA.f1OfDataset(fileNameValidation, weights, nInputs, nHidden)

              //println("Ein accuracy: " + FA.accuracyOfDataset(fileNameTraining, weights, nInputs, nHidden))
              println("Eout accuracy: " + error_out_test)
              println("Eout accuracy con datos de test: " + error_out_validation)

              hiperparametersFile.println("Eout accuracy: " + error_out_test)
              hiperparametersFile.println("Eout accuracy con datos de test: " + error_out_validation)

              //println("Ein f1: " + FA.f1OfDataset(fileNameTraining, weights, nInputs, nHidden))
              println("Eout f1: " + f1_out_test)
              println("Eout f1 con datos de test: " + f1_out_validation)

              hiperparametersFile.println("Eout f1: " + f1_out_test)
              hiperparametersFile.println("Eout f1 con datos de test: " + f1_out_validation)

              //println("Ein AUC: " + FA.aucOfDataset(fileNameTraining, weights, nInputs, nHidden))
              //println("Eout AUC: " + FA.aucOfDataset(fileNameValidation, weights, nInputs, nHidden))
              //println("Eout AUC con datos de test: " + FA.aucOfDataset(fileNameTest, weights, nInputs, nHidden))



              outputFile.close()
              println(s"$iters,$parts")
            }
          }
        }
      }
    }
    hiperparametersFile.close()





  }
}
