package RED

import RED.Funciones_Auxiliares
import scala.io.Source

object Main {

  val FA = new Funciones_Auxiliares

  def main(args: Array[String]): Unit = {
    val fileName = "C:/Users/jorge/Desktop/TFG/REE 2007-2019 David (Preprocesado 2009-2019)/demanda_limpia_final.csv"
    //val csvReader = new CSVReader(fileName)

    //val columns: List[List[String]] = csvReader.readCSV()

    val numRowsToKeep: Int = 500000 // Número de filas que deseas mantener

    var dataRows = Source.fromFile(fileName).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.take (numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }

    // Imprimir cada fila y sus columnas
    //for (row <- dataRows) {
      //println(row.mkString(", ")) // Imprime las columnas de la fila separadas por coma
    //}

    // Eliminar la primera fila (cabecera)
    //val dataRows1 = columns.tail

    //quitamos las filas con algún valor vacío
    //val dataRows2 = dataRows1.filter(row => row.forall(value => value.nonEmpty))



    //val dataRows: List[List[String]] = dataRows2.take(numRowsToKeep)

    // Acceder a las columnas individualmente
    var dates = dataRows.map(_(5))
    var hourColumn = dataRows.map(_(0))
    var potProgramadaString = dataRows.map(_(3))


    println(potProgramadaString.mkString(", "))


    val potProgramada = potProgramadaString.map(_.toDouble)



    var daysOfWeek = FA.convertToDayOfWeek(dates)

    //for ((date, dayOfWeek) <- dates.zip(daysOfWeek)) {
      //println(s"$date: $dayOfWeek")
    //}

    var (hours, minutes) = FA.separateHourMinute(hourColumn)

    val oneHotHours = FA.encode(hours)
    val oneHotMinutes = FA.encode(minutes)
    val oneHotDays = FA.encode(daysOfWeek)

    //Intentamos liberar memoria
    dataRows = null
    potProgramadaString = null
    dates = null
    hourColumn = null
    hours = null
    minutes = null
    daysOfWeek = null


    //oneHotHours.foreach(row => println(row.mkString(", ")))

    val combinedMatrix1 = oneHotDays.zip(oneHotHours).map { case (rowA, rowB) =>
      rowA ++ rowB
    }

    val numRowsCM1: Int = combinedMatrix1.length
    val numRowsOHM: Int = oneHotMinutes.length

    println(s"Número de filas CM1: $numRowsCM1")
    println(s"Número de filas OHM: $numRowsOHM")

    val combinedMatrix2 = combinedMatrix1.zip(oneHotMinutes).map { case (rowA, rowB) =>
      rowA ++ rowB
    }

    val data = combinedMatrix2.zip(potProgramada).map { case (row, value) =>
      row :+ value
    }


    // Imprime la matriz combinada
    data.foreach(row => println(row.mkString(", ")))


  }
}
