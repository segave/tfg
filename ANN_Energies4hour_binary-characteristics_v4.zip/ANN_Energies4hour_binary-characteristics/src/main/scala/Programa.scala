import java.io.{FileWriter, PrintWriter}
import scala.io.Source

object Programa {
  val FA = new Funciones_Auxiliares
  def main(args: Array[String]): Unit = {
    //Archivos para las gráficas
  val file_1 = new FileWriter(s"errores_iter_part.txt", true)
  val file_2 = new FileWriter(s"tiempo_iters.txt", true)

  val graf_1 = new PrintWriter(file_1)
  val graf_2 = new PrintWriter(file_2)

  val rowsToKeep = List(1008, 10080, 30420)

  for (nr <- rowsToKeep) {
    //val fileName = "../demanda_limpia_final.csv"
    val fileName = "C:/Users/jorge/Desktop/TFG/REE 2007-2019 David (Preprocesado 2009-2019)/demanda_limpia_final.csv" //tamaño : 175104 datos
    val numRowsToKeep: Int = nr
    val pos_max: Double = 0.8
    var dataRows = Source.fromFile(fileName).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) //filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    ////
    val dates = dataRows.map(_(4))
    val potReal = dataRows.map(_(1)).map(_.toDouble)
    val potProgramada = dataRows.map(_(3)).map(_.toDouble)
    val (days, hours) = FA.separateDayHourMinuteSecond(dates)
    val daysOfWeek = FA.convertToDayOfWeek(days)
    var (h, mi) = FA.separateHourMinute(hours)
    val oneHotHours = FA.encode(h)
    val oneHotMinutes = FA.encode(mi)
    val oneHotDays = FA.encode(daysOfWeek)
    val combinedMatrix1 = oneHotHours.zip(oneHotDays).map { case (rowA, rowB) => rowA ++ rowB }
    val combinedMatrix2 = combinedMatrix1.zip(oneHotMinutes).map { case (rowA, rowB) => rowA ++ rowB }
    val dataList = combinedMatrix2.zip(potProgramada).map { case (row, value) => row :+ value }
    val data: List[Array[Double]] = dataList.map(_.toArray)
    val separatedData: Array[List[Array[Double]]] = Array.fill(24)(List.empty)
    val separatedPotReal: Array[List[Double]] = Array.fill(24)(List.empty)
    for ((array, index) <- data.zipWithIndex) {
      for (hour <- 0 until 24) {
        if (array(hour) == 1.0) {
          separatedData(hour) = array.slice(24, array.length) :: separatedData(hour)
          separatedPotReal(hour) = potReal(index) :: separatedPotReal(hour)
        }
      }
    }
    /////
    val nInputs: Int = separatedData(0).headOption.map(_.size).getOrElse(0)
    println("Número de inputs: " + nInputs)
    val nHidden: Int = (1.9 * nInputs).toInt
    //val nHidden: Int = 5
    println("Número de ocultas: " + nHidden)
    println("Número de valores-peso: " + nHidden * (nInputs + 1))
    val arrayWeights: Array[Array[Double]] = Array.fill(24)(Array.empty[Double])
    //////////

    ////////////////
    //////////////
    val num_iteraciones = List(100)
    val num_particulas = List(10, 100, 1000)

    for (iters <- num_iteraciones) {
      for (parts <- num_particulas) {
        // Número de partículas
        val m = parts
        // Número de iteraciones
        val I = iters

        val existingFile = new FileWriter(s"resultados_ANN_energies_Full$I _$m _$numRowsToKeep.txt", true)
        //val existingFile = new FileWriter(s"resultados_sonar_secuencial_$iters _$parts.txt", true)
        val weightsFile = new FileWriter(s"vector_pesos_ANN_energies$I _$m _$numRowsToKeep.csv", true)
        val outputFile = new PrintWriter(existingFile)
        val weigthOutput = new PrintWriter(weightsFile)

        val start = System.nanoTime()
        //Ejecución de la variante DAPSO del algoritmo
        for (hour <- 0 until 24) {
          val trainer = new DAPSO(separatedData(hour), separatedPotReal(hour), nInputs, nHidden, I, m, pos_max)
          //val trainer = new pso_secuencial(separatedData(hour), separatedPotReal(hour), nInputs, nHidden, I, m, pos_max)
          trainer.inicializar_pesos()
          trainer.procesar()
          arrayWeights(hour) = trainer.get_pesos()
        }
        val end = System.nanoTime()
        ////////////////Se guardan los pesos calculados en un archivo
        for (hour <- 0 until 24) {
          val mejor_pos_global = arrayWeights(hour)
          println(s"vector pesos_hora:$hour " + mejor_pos_global.mkString(", "))
          println("tamaño del vector de pesos: " + mejor_pos_global.size)
          weigthOutput.println(mejor_pos_global.mkString(", "))
        }


        ////////////////
        /*val fileName2 = "vector_pesos_ANN_energies1000 _100.csv"
        var weigths = Source.fromFile(fileName2).getLines.filter { line =>
          val cols = line.split(",").map(_.trim)
          cols.forall(_.nonEmpty)
        }.take(24).toList.map { line =>
          val cols = line.split(",").map(_.trim)
          cols
        }
        val weigths_arr = weigths.toArray
        var weigths_arr_double:Array[Array[Double]]=Array.fill(24)(Array(0.0))
        for (i<-0 until weigths_arr.length){
          weigths_arr_double(i) = weigths_arr(i).map(_.toDouble)
         // println(s"vector pesos para la hora$i:  "+ weigths_arr_double(i).mkString(", "))
        }*/
        //////

        val keyValueMap: Map[Int, String] = Map(
          0 -> "00:00",
          1 -> "01:00",
          2 -> "02:00",
          3 -> "03:00",
          4 -> "04:00",
          5 -> "05:00",
          6 -> "06:00",
          7 -> "07:00",
          8 -> "08:00",
          9 -> "09:00",
          10 -> "10:00",
          11 -> "11:00",
          12 -> "12:00",
          13 -> "13:00",
          14 -> "14:00",
          15 -> "15:00",
          16 -> "16:00",
          17 -> "17:00",
          18 -> "18:00",
          19 -> "19:00",
          20 -> "20:00",
          21 -> "21:00",
          22 -> "22:00",
          23 -> "23:00",
        )
        ///////////////
        var potPredicha: Array[List[Double]] = Array.fill(24)(List.empty[Double])
        //Predicción
        //val start = System.nanoTime()

        for (hour <- 0 until 24) {
          for (i <- 0 until separatedData(hour).length) {
            val pot = FA.forwardProp(separatedData(hour)(i), arrayWeights(hour), nInputs, nHidden)
            //val pot = FA.forwardProp(separatedData(hour)(i), weigths_arr_double(hour), nInputs, nHidden)
            potPredicha(hour) = potPredicha(hour) :+ pot
          }
        }
        //val end = System.nanoTime()
        //Resultados
        var error = 0.0
        for (hour <- 0 until 24) {
          println("Resultados para " + keyValueMap(hour))
          outputFile.println("Resultados para " + keyValueMap(hour))
          error += FA.MSEOfData(potPredicha(hour), separatedPotReal(hour))
          for ((real, predicho) <- separatedPotReal(hour).zip(potPredicha(hour))) {
            println(s"Potencia real: $real - Potencia predicha: $predicho")
            outputFile.println(s"$real,$predicho")
          }
        }
        error = error / 24.0

        /////////
        val tiempo = (end - start) / 1e9
        println(s"Tiempo de ejecucion(s):$tiempo")
        /////////
        //rellenamos los archivos para las gráficas

        //val error = FA.MSEOfDataSeparated(separatedData, separatedPotReal, arrayWeights, nInputs, nHidden)

        graf_1.println(s"$iters, $parts, $numRowsToKeep, $error")
        graf_2.println(s"$iters, $parts, $numRowsToKeep, $tiempo")

        outputFile.close()
        weigthOutput.close()

      }
    }

  }
  graf_1.close()
  graf_2.close()
  //outputFile.println(s"$tiempo")
  }
}
