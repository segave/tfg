import akka.actor.typed.scaladsl.{ActorContext, Behaviors}
import akka.actor.typed.{ActorRef, ActorSystem, Behavior}
//Ejemplo sacado de  "2nd Edition of the Scala Cookbook", Alvin Alexander
object ThermostatApp {
  object ThermostatActor{
    import ThermostatSupervisor.{StringMessage, SystemMessage}

    var currentTemp = 26
    //Método factoría para definir los mensajes que podemos
    //enviar; en realidad, se define la API del actor
    sealed trait MessageToThermostat{
      def sender: ActorRef[SystemMessage]
    }
    final case class CurrentTemperature(sender: ActorRef[SystemMessage])
      extends MessageToThermostat
    final case class IncreaseTemperature(
       sender: ActorRef[SystemMessage],
       amount: Int
       ) extends MessageToThermostat
    final case class DecreaseTemperature(
       sender: ActorRef[SystemMessage],
       amount: Int
       ) extends MessageToThermostat
    def apply():Behavior[MessageToThermostat]= Behaviors.setup {
      context: ActorContext[MessageToThermostat] =>
        Behaviors.receiveMessage { message =>
          message match {
            case CurrentTemperature(sender) =>
              sendReply(sender)
              Behaviors.same
            case IncreaseTemperature(sender, amount) =>
              currentTemp += amount
              sendReply(sender)
              Behaviors.same
            case DecreaseTemperature(sender, amount) =>
              currentTemp -= amount
              sendReply(sender)
              Behaviors.same
          }
        }
    }
    private def sendReply(sender: ActorRef[SystemMessage])={
      val msg = s"Termostato: La temperatura es $currentTemp grados C"
      println(msg)
      sender ! StringMessage(msg)
    }
  }
  import ThermostatActor._
  object ThermostatSupervisor{
    //estos son los mensajes que podemos recibir; algunos nos serán
    // enviados desde la aplicación, otros nos los envía el ThermostatActor.
    sealed trait SystemMessage
    case object StartSendingMessages extends SystemMessage
    case object StopSendingMessages extends SystemMessage
    case class StringMessage(msg: String) extends SystemMessage
    //Ahora la definición del método factoría apply()
    def apply(): Behavior[SystemMessage]= Behaviors.setup[SystemMessage]{
      actorContext=>
        val thermostat = actorContext.spawn(ThermostatActor(), "ThermostatActor")
        Behaviors.receiveMessage{
          case StartSendingMessages=>
            thermostat ! CurrentTemperature(actorContext.self)
            thermostat ! IncreaseTemperature(actorContext.self, 1)
            thermostat ! DecreaseTemperature(actorContext.self, 2)
            Behaviors.same
          case StopSendingMessages =>
            Behaviors.stopped
          case StringMessage(msg) =>
            println(s"MSG: $msg")
            Behaviors.same
        }
    }
  }
  def main(args: Array[String]):Unit={
    import ThermostatSupervisor.{StartSendingMessages, StopSendingMessages, SystemMessage}
    println("Hello World!!!")
    val actor: ActorSystem[SystemMessage]= ActorSystem(ThermostatSupervisor(), "ThermostatSupervisor")
    actor ! StartSendingMessages
    Thread.sleep(1_000)
    actor ! StopSendingMessages
    Thread.sleep(500)
    actor.terminate()
  }
}
