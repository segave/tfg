package RED
import scala.concurrent._

import scala.util.Random
//import RED.Funciones_Auxiliares

import scala.collection.mutable.ListBuffer

import akka.actor.typed.scaladsl.{ActorContext, Behaviors}
import akka.actor.typed.{ActorRef, Behavior, ActorSystem}

// Definir un actor para evaluar el mejor global y actualizar de forma asíncrona

object GlobalEvalActor {

  import FitnessEvalActor._

  sealed trait SystemMessage

  case object StartSendingMessages extends SystemMessage

  case object ContinueSendingMessages extends SystemMessage

  case object StopSendingMessages extends SystemMessage

  //Definimos las variables que necesitamos
  val FA = new Funciones_Auxiliares
  var best_global_fitness = Double.MaxValue
  var mejor_pos_global: Array[Double] = _
  private var fuch: Channel[ListBuffer[Array[Double]]] = _
  private var srch: Channel[Lote] = _
  private var N: Int = _
  private var S: Int = _
  private var I: Int = _
  private var m: Int = _
  private var rand: Random = _
  private var W: Double = _
  private var c_1: Double = _
  private var c_2: Double = _
  private var V_max: Double = _
  private var particulas: Array[Array[Double]] = _
  private var pos_max: Double = _


  def initialize(srch: Channel[Lote], fuch: Channel[ListBuffer[Array[Double]]], N: Int, S: Int, I: Int, m: Int,
                 rand: Random, W: Double, c1: Double, c2: Double, pos_max: Double, particulas: Array[Array[Double]]): Unit = {
    GlobalEvalActor.fuch = fuch
    GlobalEvalActor.srch = srch
    GlobalEvalActor.N = N
    GlobalEvalActor.S = S
    GlobalEvalActor.I = I
    GlobalEvalActor.m = m
    GlobalEvalActor.rand = rand
    GlobalEvalActor.W = W
    GlobalEvalActor.c_1 = c1
    GlobalEvalActor.c_2 = c2
    GlobalEvalActor.V_max = 0.1*pos_max
    GlobalEvalActor.pos_max = pos_max
    GlobalEvalActor.particulas = particulas
    GlobalEvalActor.best_global_fitness = Double.MaxValue
    GlobalEvalActor.mejor_pos_global = Array.empty[Double]
  }

  def apply(dapsoController: DAPSOController): Behavior[SystemMessage] = Behaviors.setup[SystemMessage] {
    actorContext =>
      val fitnessEvalActor = actorContext.spawn(FitnessEvalActor(), "FitnessEvalActor")
      //val resultsActor = actorContext.spawn(ResultsActor(), "ResultsActor")


      val lote = new Lote(S)

      //añadimos las partículas a la cola
      for (i <- 0 until m) {
        if (lote.estaCompleto) {
          srch.write(lote.copiar())
          fitnessEvalActor ! ContinueReceivingMessage()
          lote.clean()
        }
        lote.agregar(particulas(i))
      }

      Behaviors.receiveMessage {
        case StartSendingMessages =>
          //println("Start Global Actor task")

          //resultsActor ! StartTime()

          val iters = I * m / S
          for (i <- 0 until iters) {
            println("iter " + i + " dentro de globalActor")
            // Esperar un elemento del canal fuch
            var sr = fuch.read

            var pos: Array[Double] = new Array[Double](0)
            var velocidad: Array[Double] = new Array[Double](0)
            var mpl: Array[Double] = new Array[Double](0)
            var fit: Double = 0

            for (par <- sr) {
              pos = par.slice(0, N)
              velocidad = par.slice(N, 2 * N)
              mpl = par.slice(2 * N, 3 * N)
              fit = par(3 * N)

              if (fit < best_global_fitness) {
                best_global_fitness = fit
                mejor_pos_global = mpl
              }
              val newPar = FA.posEval(par, mejor_pos_global, N, rand, W, c_1, c_2, V_max, pos_max)
              if (lote.estaCompleto) {
                srch.write(lote.copiar())
                fitnessEvalActor ! ContinueReceivingMessage()
                lote.clean()
              }
              lote.agregar(newPar)
            }
            sr = null
            //println("mejor posición actual " + mejor_pos_global.mkString(", "))

            pos = null
            velocidad = null
            mpl = null
          }



          actorContext.self ! StopSendingMessages

          Behaviors.same
        case StopSendingMessages =>
          //resultsActor ! EndTime()
          //println("Los resultados globales del cálculo!!!")
          //println(s"mejor_pos_global-> ${mejor_pos_global.mkString("[", ", ", "]")}")
          //println(s"mejor fitness global-> $best_global_fitness")
          dapsoController.recibirResultado(mejor_pos_global, best_global_fitness)
          Behaviors.stopped
      }
  }
}

