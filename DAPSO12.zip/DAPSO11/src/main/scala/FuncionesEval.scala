import org.apache.spark.broadcast.Broadcast

import scala.collection.mutable.ListBuffer
import scala.concurrent._
import scala.util.Random

class FuncionesEval extends Serializable {
  val FA = new FuncionesAuxiliares
  def InitParticles(N: Int, M: Int, bgf: Double, mpg: Array[Double], rand: Random, objetivo: Broadcast[Array[Double]]): (Double, Array[Double], Array[Array[Double]]) = {
    var parts_ = Array.empty[Array[Double]]
    var best_global_fitness = bgf
    var mejor_pos_global = mpg


    for (j <- 0 until M) {
      val posicion = Array.fill(N)(FA.Uniform(100, rand))
      val velocidad = Array.fill(N)(FA.Uniform(100, rand))
      val fit = FA.MSE(posicion, objetivo)
      val part_ = posicion ++ velocidad ++ posicion ++ Array(fit)

      //best_local_fitness_arr = best_local_fitness_arr :+ fit
      if (fit < best_global_fitness) {
        best_global_fitness = fit
        //accum.setValue(fit)
        mejor_pos_global = posicion
      }
      parts_ = parts_ :+ part_
    }
    (best_global_fitness, mejor_pos_global, parts_)
  }
//ListBuffer es una lista que cambia constantemente. La clase List de Scala
  //contiene una lista secuencial y lineal de elementos.
  //Una Lista puede ser construida eficientemente sólo de atrás hacia adelante.
  //El objeto ListBuffer es conveniente cuando queremos construir una lista
  //de adelante hacia atrás y soporta operaciones eficientes de prepend y
  // append:
  //listBuffer += e
  //listBuffer ++= Seq(e1,e2,...en)
  //listBuffer.insert(pos_ins,n1)
  //listBuffer.update(pos,n1)
  //listBuffer.remove (pos), listBuffer.remove (pos1,pos2) (los elimina entre ambas posiciones)
  //Constructor: val listBuffer = ListBuffer[Tipo]()
  //val listBuffer = ListBuffer[Int](), para generar un ListBuffer de enteros

  // Convertir el Array[Array[Double]] a un ListBuffer[Array[Double]]
  def toListBuffer(arrayArray: Array[Array[Double]]): ListBuffer[Array[Double]] = {
    val listBuffer: ListBuffer[Array[Double]] = ListBuffer.empty[Array[Double]]

    // Recorrer cada subarray en el Array[Array[Double]] y convertirlo a un List[Double]
    for (subArray <- arrayArray) {
      val list: List[Double] = subArray.toList
      // Agregar el List[Double] al ListBuffer[Array[Double]]
      listBuffer += list.toArray
    }
    listBuffer
  }
//Calcular el fitness de las partículas
def fitnessEval(part: Array[Double], N: Int,
                objetivo: Broadcast[Array[Double]]): Array[Double] = {
  if (part == null) {
    println("El array es null")
    return Array.empty[Double]
  }
  val best_fit_local = part(3 * N)
  val filas = part.slice(0, N)
  val fit = FA.MSE(filas, objetivo)
  if (fit < best_fit_local) {
    part(3 * N) = fit
    for (k <- 0 until N) {
      part(2 * N + k) = filas(k)
    }
  }
  part
}
//Calcula la siguiente posición de la partícula
  def posEval(part: Array[Double], mpg: Array[Double], N: Int,
      rand: Random, W: Double, c_1: Double, c_2: Double, V_max: Double): Array[Double] = {
    // global ind (no es necesario en Scala)
    val velocidades = part.slice(N, 2 * N)
    val mpl = part.slice(2 * N, 3 * N)
    val r_1 = rand.nextDouble()
    val r_2 = rand.nextDouble()
    for (k <- 0 until N) {
      velocidades(k) = W * velocidades(k) + c_1 * r_1 * (mpl(k) - part(k)) + c_2 * r_2 * (mpg(k) - part(k))
      if (velocidades(k) > V_max) {
        velocidades(k) = V_max
      } else if (velocidades(k) < -V_max) {
        velocidades(k) = -V_max
      }
      part(k) = part(k) + velocidades(k)
      part(N + k) = velocidades(k)
    }
    part
  }
}
