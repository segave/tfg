import akka.actor.typed.scaladsl.{ActorContext, Behaviors}
import akka.actor.typed.{ActorRef, ActorSystem, Behavior}
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ListBuffer
import scala.concurrent._
import scala.concurrent.duration.Duration
import scala.util.Random

object DAPSO {
  val FA = new FuncionesAuxiliares
  val FE = new FuncionesEval
  val spark: SparkSession = SparkSession.builder()
    .master("local[*]")
    .appName("DAPSO")
    .getOrCreate()
  val conf = new SparkConf().setAppName("PSO Distribuido y Paralelo").setMaster("local[*]")
  val sc = SparkContext.getOrCreate(conf)
  val objetivo_ = Array[Double](50.0,50.0,50.0)
  val objetivo = sc.broadcast(objetivo_)
  //aleatorio
  val rand_ = new Random()
  //Constantes del PSO
  val V_max =10.0
  val W = 1.0
  val c_1 = 0.0
  val c_2 = 0.2
  //Dimensión de los vectores
  val n = 3
  //Número de partículas
  val m = 30
  //número de partículas por lote
  val S = 5
  //Número de iteraciones
  val I = 100000
  //declaración de variables globales y valores vacios
  var particulas = Array.empty[Array[Double]]
  var mejor_pos_global_arr = Array.fill(n)(0.0)
  //Valores máximos
  var best_global_fitness = Double.MaxValue
  var mejor_pos_global = mejor_pos_global_arr
  //Definición de los Channel
  val srch = new Channel[Lote]()
  val fuch = new Channel[ListBuffer[Array[Double]]]()


  object FitnessEvalActor {
    import GlobalEvalActor.SystemMessage
    sealed trait MessageToFitnessActor{
      def sender: ActorRef[SystemMessage]
    }
    final case class ContinueReceivingMessage (sender: ActorRef[SystemMessage]) extends MessageToFitnessActor
    private var srch: Channel[Lote] = _
    private var fuch: Channel[ListBuffer[Array[Double]]] = _
    private var sc: SparkContext = _

    def initialize(srch:Channel[Lote], fuch:Channel[ListBuffer[Array[Double]]],sc:SparkContext): Unit={
      FitnessEvalActor.srch = srch
      FitnessEvalActor.fuch = fuch
      FitnessEvalActor.sc = sc
    }
    def apply():Behavior[MessageToFitnessActor] = Behaviors.setup{
      context: ActorContext[MessageToFitnessActor] =>
        Behaviors.receiveMessage { message =>
          message match {
            case ContinueReceivingMessage(sender) =>
           //   println("Evaluando fitness")
              val batch =srch.read
              val aux = batch.obtenerLote.toArray
              val RDD = sc.parallelize(aux)
              val psfu_array = RDD.map(x=>FE.fitnessEval(x,n,objetivo)).collect()
              val psfu = FE.toListBuffer(psfu_array)
              fuch.write(psfu)
          //    println("Fitness Actor task write to fuch")
              Behaviors.same
          }
        }
    }
  }

  object GlobalEvalActor{
    import FitnessEvalActor._
    sealed trait SystemMessage
    case object StartSendingMessages extends SystemMessage
    case object ContinueSendingMessages extends SystemMessage
    case object StopSendingMessages extends SystemMessage
    private var srch: Channel[Lote] = _
    private var fuch: Channel[ListBuffer[Array[Double]]] = _
    private var N: Int = _
    private var S: Int = _
    private var I: Int = _
    private var m: Int = _
    private var rand: Random = _
    private var particulas: Array[Array[Double]] = _

    def initialize(srch:Channel[Lote], fuch:Channel[ListBuffer[Array[Double]]], N:Int , S:Int, I: Int, m: Int, rand: Random, particulas:Array[Array[Double]]): Unit={
      GlobalEvalActor.fuch= fuch
      GlobalEvalActor.srch= srch
      GlobalEvalActor.N = N
      GlobalEvalActor.S = S
      GlobalEvalActor.m = m
      GlobalEvalActor.I = I
      GlobalEvalActor.rand = rand
      GlobalEvalActor.particulas= particulas
    }

    def apply(): Behavior[SystemMessage]= Behaviors.setup[SystemMessage]{
      actorContext=>
        val fitnessEvalActor= actorContext.spawn(FitnessEvalActor(),"FitnessEvalActor")
        val lote = new Lote(S)

        //añadimos las partículas a la cola
        for (i <- 0 until m) {
          if (lote.estaCompleto) {
            srch.write(lote.copiar())
          //  println("Global Actor task write to srch")
            fitnessEvalActor ! ContinueReceivingMessage(actorContext.self)
            lote.clean()
          }
          lote.agregar(particulas(i))
        }
     /*   val schema = new StructType()
          .add("posicion", ArrayType(DoubleType))
          .add("velocidad", ArrayType(DoubleType))
          .add("mejor pos global", ArrayType(DoubleType))
          .add("error", DoubleType)

        println("Estructura inicial con todas particulas(posicion, velocidad, mejor_pos,error): ")
    */
        //val df = spark.createDataFrame(spark.sparkContext.parallelize(particulas.map(Row(_))), schema)
    /*    val df= spark.createDataFrame(sc.parallelize(particulas.map(Row(_))),schema)
        df.printSchema()
        df.show()
    */
        Behaviors.receiveMessage{
          case StartSendingMessages=>
         //   println("Start Global Actor task")
            //Simula la llamada a aggregator.recibir(nueva_particula)
            //Thread.sleep(1_000)
            val iters = I*m/S
            for (i<-0 until iters) {
           //   println("Global Actor task-Iter "+i)
              var sr = fuch.read
           //   println("Global Actor task read from fuch")
              //posicion y velocidad de la partícula
              var pos: Array[Double] = new Array[Double](0)
              var velocidad: Array[Double] = new Array[Double](0)
              //mejor posición local de la partícula
              var mpl:Array[Double] = new Array[Double](0)
              //fitness de la partícula
              var fit: Double = 0
              for (par<-sr){//recorremos las partículas del channel fuch
                pos = par.slice(0,n)//en la primara rodaja se encuentra la posicion de la part
                velocidad = par.slice(n, 2*n) //en la segunda roja se encuentra la velocidad de la paricula
                mpl = par.slice(2*n,3*n) //en la tercera rodaja se encuentra la mejor posicion de la particula hasta ese momento
                fit= 3*n //en la última posición está el fitness de la partícula
                if (fit < best_global_fitness){
                  best_global_fitness = fit
                  mejor_pos_global= pos
                }
                //actualización: insercion de nueva part con la posición y velocidad actualizadas
                val newPar = FE.posEval(par,mejor_pos_global, N, rand, W, c_1, c_2, V_max)

                if(lote.estaCompleto){
                  srch.write(lote.copiar)
                  fitnessEvalActor ! ContinueReceivingMessage(actorContext.self)
                  lote.clean()
                }
                lote.agregar(newPar)
              }
              sr = null
             // println("mejor posición global actual " + mejor_pos_global.mkString(", "))
              pos = null
              velocidad = null
              mpl = null
            }
            fitnessEvalActor ! ContinueReceivingMessage(actorContext.self)
            println(s"mejor_pos_global final-> ${mejor_pos_global.mkString("[", ", ", "]")}")
            println(s"mejor fitness global final-> $best_global_fitness")
            actorContext.self ! StopSendingMessages
            Behaviors.same
          case StopSendingMessages=>
            println("Los resultados globales del cálculo!!!")
            Behaviors.stopped
        }
    }
  }
  def main(args: Array[String]): Unit = {
    import GlobalEvalActor.{StartSendingMessages, StopSendingMessages, SystemMessage}
    //Inicialización de las partículas
    //var arrayDeArrays= Array.empty[Array[Double]]
    var resultado: (Double, Array[Double], Array[Array[Double]]) =
      FE.InitParticles(n, m, best_global_fitness, mejor_pos_global, rand_, objetivo)
    val (best_global_fitness_, mejor_pos_global_, arrayDeArrays) = resultado
    //inicilaización de las variables globales
    best_global_fitness= best_global_fitness_
    mejor_pos_global= mejor_pos_global_
    particulas= arrayDeArrays
    var tiempo_fitness= 0.0
    var tiempo_poseval = 0.0
    var tiempo_global = 0.0
    var tiempo_collect = 0.0
    var tiempo_foreach = 0.0
    //Comprobación
    import org.apache.spark.sql.functions._
    import org.apache.spark.sql.types.StructType._
 //   println("Mejor fitness global inicial: "+best_global_fitness)

  //  println("Mejor posición global inicial: ")
 //   mejor_pos_global.map(x=>print(" "+x))


//Tiempo de inicio de los cálculos
    val start = System.nanoTime()

    val actor: ActorSystem[SystemMessage]= ActorSystem(GlobalEvalActor(),"GlobalEvalActor" )
    GlobalEvalActor.initialize(srch,fuch,n,S,I,m,rand_,particulas)
    FitnessEvalActor.initialize(srch, fuch, sc)

    actor ! StartSendingMessages
    //Thread.sleep(1_000)

    actor ! StopSendingMessages
    //Thread.sleep(500)
    //globalEvalActor.terminate()

    Await.result(actor.whenTerminated, Duration.Inf)

  //  actor.whenTerminated.onComplete { _ =>
      println("Finalizado el actor Global !!!")
      val end = System.nanoTime()

      val tiempo = (end - start) / 1e9
      println(s"Tiempo de ejecucion(s):$tiempo")
  //  }
    println("Se acabó!!!")
  }

}
