import scala.io.Source

object Programa {
  val FA = new Funciones_Auxiliares
  def main(args: Array[String]): Unit={
    //val fileName = "../demanda_limpia_final.csv"
    val fileNameTraining = "C:/Users/jorge/Desktop/TFG/consumos/training2.csv"
    val fileNameTest = "C:/Users/jorge/Desktop/TFG/consumos/test.csv"
    //val numRowsToKeep: Int = 175104 //Número de filas que queremos mantener
    //val numRowsToKeep: Int = 701107
    val numRowsToKeep: Int = 1200

    //Importo la información de los archivos
    var dataRowsTraining = Source.fromFile(fileNameTraining).getLines.drop(1).filter{line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty)//filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map{line=>
      val cols = line.split(",").map(_.trim)
      cols
    }
    var dataRowsTest = Source.fromFile(fileNameTest).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) //filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    //val res0: List[Array[String]] = List(Array(2009-01-01 00:00:00, 25.987), Array(2009-01-01 00:10:00, 25.98),
    // Array(2009-01-01 00:20:00, 26.05), Array(2009-01-01 00:30:00, 25.943), Array(2009-01-01 00:40:00, 25.794),
    // Array(2009-01-01 00:50:00, 25.616), Array(2009-01-01 01:00:00, 25.399), Array(2009-01-01 01:10:00, 25.144000000000002),
    // Array(2009-01-01 01:20:00, 24.941999999999997), Array(2009-01-01 01:30:00, 24.388))  ...

    val (dataTraining, potRealTraining) = FA.crearDataTraining(dataRowsTraining)
    val (dataTest, potRealTest) = FA.crearDataTest(dataRowsTest)

    //Separamos los datos según la hora
    val separatedDataTraining: Array[List[Array[Double]]] = Array.fill(24)(List.empty)
    val separatedDataTest: Array[List[Array[Double]]] = Array.fill(24)(List.empty)
    val separatedPotRealTraining: Array[List[Double]] = Array.fill(24)(List.empty)
    val separatedPotRealTest: Array[List[Double]] = Array.fill(24)(List.empty)

    // Iterar sobre cada array en data y asignarlo a la lista correspondiente según la hora
    for ((array, index) <- dataTraining.zipWithIndex) {
      for (hour <- 0 until 24) {
        if (array(hour) == 1.0) {
          separatedDataTraining(hour) = array :: separatedDataTraining(hour)
          separatedPotRealTraining(hour) = potRealTraining(index) :: separatedPotRealTraining(hour)
        }
      }
    }
    for ((array, index) <- dataTest.zipWithIndex) {
      for (hour <- 0 until 24) {
        if (array(hour) == 1.0) {
          separatedDataTest(hour) = array :: separatedDataTest(hour)
          separatedPotRealTest(hour) = potRealTest(index) :: separatedPotRealTest(hour)
        }
      }
    }

//////////////
    val nInputs: Int = dataTraining.headOption.map(_.size).getOrElse(0)
    //Número de neuronas de la capa oculta < 2*(numero de neoronas de la capa de entrada)
    println(s"Numero de inputs: $nInputs")
    val nHidden: Int =  (1.9*nInputs).toInt
    println(s"Numero de hiddens: $nHidden")

    val arrayWeights: Array[Array[Double]] = Array.fill(24)(Array.empty[Double])
    val start = System.nanoTime()
    //Ejecución de la variante DAPSO del algoritmo
    for (hour <- 0 until 24){
      val trainer = new DAPSO(separatedDataTraining(hour), potRealTraining, nInputs, nHidden)
      trainer.inicializar_pesos()
      val start = System.nanoTime()
      trainer.procesar()
      arrayWeights(hour) = trainer.get_pesos()
    }
    val end = System.nanoTime()


    ///////
    var potPredicha: Array[List[Double]] = Array.fill(24)(List.empty[Double])
    //Predicción
    for (hour <- 0 until 24){
      for (i <- 0 until separatedDataTest(hour).length) {
        val pot = FA.forwardProp(separatedDataTest(hour)(i), arrayWeights(hour), nInputs, nHidden)
        potPredicha(hour) = potPredicha(hour) :+ pot
      }
    }

    val keyValueMap: Map[Int, String] = Map(
      0 -> "00:00",
      1 -> "01:00",
      2 -> "02:00",
      3 -> "03:00",
      4 -> "04:00",
      5 -> "05:00",
      6 -> "06:00",
      7 -> "07:00",
      8 -> "08:00",
      9 -> "09:00",
      10 -> "10:00",
      11 -> "11:00",
      12 -> "12:00",
      13 -> "13:00",
      14 -> "14:00",
      15 -> "15:00",
      16 -> "16:00",
      17 -> "17:00",
      18 -> "18:00",
      19 -> "19:00",
      20 -> "20:00",
      21 -> "21:00",
      22 -> "22:00",
      23 -> "23:00",
    )

    //Resultados
    for (hour <- 0 until 24){
      println("Resultados para " + keyValueMap(hour))
      for ((real, predicho) <- separatedPotRealTest(hour).zip(potPredicha(hour))) {
        println(s"Potencia real: $real - Potencia predicha: $predicho")
      }
    }


    val tiempo = (end - start) / 1e9
    println(s"Tiempo de ejecucion(s):$tiempo")
    //val best_global_fitness = trainer.get_best_global_fitness()
    //println(s"mejor fitness global final-> $best_global_fitness")
    //val mejor_pos_global = trainer.get_pesos()
    //println("mejor posición global final " + mejor_pos_global.mkString(", "))
  }
}
