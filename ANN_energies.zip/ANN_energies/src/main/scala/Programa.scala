import scala.io.Source

object Programa {
  val FA = new Funciones_Auxiliares
  def main(args: Array[String]): Unit={
    val fileName = "../demanda_limpia_final.csv"
   // val fileName = "../training2.csv"//tamaño : 175104 datos
    //val numRowsToKeep: Int = 175104 //Número de filas que queremos mantener
    //val numRowsToKeep: Int = 701107//numero de datos de demanda_limpia_final.csv
    val numRowsToKeep: Int = 1200
    var dataRows = Source.fromFile(fileName).getLines.drop(1).filter{line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty)//filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map{line=>
      val cols = line.split(",").map(_.trim)
      cols
    }
    //var dataRows: List[Array[String]] = List(Array(00:00, 25.519, 24.79, 24.51, 2017-01-01 00:00:00, 2017-01-01),
    // Array(00:10, 25.364, 24.634, 24.51, 2017-01-01 00:10:00, 2017-01-01), Array(00:20, 25.184, 24.495, 24.51,
    // 2017-01-01 00:20 :00, 2017-01-01), Array(00:30, 24.463, 24.373, 24.51, 2017-01-01 00:30:00, 2017-01-01), ...)
    val dates =dataRows.map(_(4))
    //val dates: List[String] = List(2017-01-01 00:00:00, 2017-01-01 00:10:00, 2017-01-01 00:20:00, 2017-01-01 00:30:00,
    // 2017-01-01 00:40:00, 2017-01-01 00:50:00, 2017-01-01 01:00:00, 2017-01-01 01:10:00, 2017-01-01 01:20:00, ...)
    val (days, hours) = FA.separateDayHourMinuteSecond(dates)
    //val days: List[String] = List(2017-01-01, 2017-01-01, 2017-01-01, 2017-01-01, 2017-01-01, 2017-01-01, 2017-01-01,
    // 2017-01-01, 2017-01-01, 2017-01-01, 2017-01-01, 2017-01-01, ...)
    //val hours: List[String] = List(00:00:00, 00:10:00, 00:20:00, 00:30:00, 00:40:00, 00:50:00, 01:00:00, 01:10:00,
    // 01:20:00, 01:30:00, 01:40:00, 01:50:00, ...)
    val daysOfWeek =  FA.convertToDayOfWeek(days)
    //val months = FA.convertToMonthOfYear(days)
    var (h,m) = FA.separateHourMinute(hours)
    //var h: List[String] = List(00, 00, 00, 00, 00, 00, 01, 01, 01, 01, 01, 01, ...)
    //var m: List[String] = List(00, 10, 20, 30, 40, 50, 00, 10, 20, 30, 40, 50, ...)
    val oneHotHours = FA.encode(h)
    val oneHotMinutes = FA.encode(m)
    val oneHotDays = FA.encode(daysOfWeek)
  //  val oneHotMonths = FA.encode(months)
  //  val combinedMatrix1 = oneHotMonths.zip(oneHotDays).map{case (rowA,rowB)=> rowA ++ rowB}
    val combinedMatrix2 = oneHotDays.zip(oneHotHours).map{case (rowA,rowB)=> rowA ++ rowB}
    val combinedMatrix3 = combinedMatrix2.zip(oneHotMinutes).map{case (rowA,rowB)=> rowA ++ rowB}
    //val combinedMatrix3: List[List[Double]] = List(List(1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0),
    // List(1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0), List(1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0),
    // List(1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0), List(1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0),
    // List(1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0), List(1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0),
    // List(1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0), List(1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0),
    // List(1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0), List(1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0),
    // List(1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0) ...)
    val potReal = dataRows.map(_(1)).map(_.toDouble)
    val potProgramada =dataRows.map(_(3)).map(_.toDouble)
    //val potReal: List[Double] = List(25.519, 25.364, 25.184, 24.463, 24.345, 24.24, 24.046, 23.788,
    // 23.468000000000004, 23.208, 22.992, 22.665, ...)
    val dataList = combinedMatrix3.zip(potReal).map{case (row, value)=> row:+ value}
    //val dataList: List[List[Double]] = List(List(1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 25.519),
    // List(1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 25.364), List(1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 25.184),
    // List(1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 24.463) ...)
    val data: List[Array[Double]] = dataList.map(_.toArray)
    //val data: List[Array[Double]] = List(Array(1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 25.519),
    // Array(1.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 25.364), Array(1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 25.184),
    // Array(1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 24.463), ...)
//////////////


    val nInputs: Int = data.headOption.map(_.size).getOrElse(0)
    //Número de neuronas de la capa oculta < 1.9*(numero de neoronas de la capa de entrada)
    println(s"Numero de inputs: $nInputs")
    val nHidden: Int =  (1.9*nInputs).toInt
    println(s"Numero de hiddens: $nHidden")
    //Ejecución de la variante DAPSO del algoritmo
    val trainer = new DAPSO(data,potProgramada,nInputs,nHidden)
    trainer.inicializar_pesos()
    val start = System.nanoTime()
    trainer.procesar()
    val weights = trainer.get_pesos()
    ///////
    var potPredicha: List[Double] = List()
    //Predicción
    for (i <- 0 until data.length) {
      val pot = FA.forwardProp(data(i), weights, nInputs, nHidden)
      potPredicha = potPredicha :+ pot
    }
    //Resultados
    for ((real, predicho) <- potReal.zip(potPredicha)) {
      println(s"Potencia real: $real - Potencia predicha: $predicho")
    }
    val end = System.nanoTime()
    val tiempo = (end - start) / 1e9
    println(s"Tiempo de ejecucion(s):$tiempo")
    val best_global_fitness = trainer.get_best_global_fitness()
    println(s"mejor fitness global final-> $best_global_fitness")
    val mejor_pos_global = trainer.get_pesos()
    println("mejor posición global final " + mejor_pos_global.mkString(", "))
  }
}
