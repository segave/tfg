import scala.io.Source

object Programa {
  val FA = new Funciones_Auxiliares
  def main(args: Array[String]): Unit={
    //val fileName = "../demanda_limpia_final.csv"
    val fileName = "../training2.csv"
    //val numRowsToKeep: Int = 175104 //Número de filas que queremos mantener
    //val numRowsToKeep: Int = 701107
    val numRowsToKeep: Int = 1200
    var dataRows = Source.fromFile(fileName).getLines.drop(1).filter{line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty)//filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map{line=>
      val cols = line.split(",").map(_.trim)
      cols
    }
    //val res0: List[Array[String]] = List(Array(2009-01-01 00:00:00, 25.987), Array(2009-01-01 00:10:00, 25.98),
    // Array(2009-01-01 00:20:00, 26.05), Array(2009-01-01 00:30:00, 25.943), Array(2009-01-01 00:40:00, 25.794),
    // Array(2009-01-01 00:50:00, 25.616), Array(2009-01-01 01:00:00, 25.399), Array(2009-01-01 01:10:00, 25.144000000000002),
    // Array(2009-01-01 01:20:00, 24.941999999999997), Array(2009-01-01 01:30:00, 24.388))  ...

    val dates =dataRows.map(_(4))
    val (days, hours) = FA.separateDayHourMinuteSecond(dates)
    val daysOfWeek =  FA.convertToDayOfWeek(days)
    //val months = FA.convertToMonthOfYear(days)
    var (h,m) = FA.separateHourMinute(hours)
    val oneHotHours = FA.encode(h)
    val oneHotMinutes = FA.encode(m)
    val oneHotDays = FA.encode(daysOfWeek)
  //  val oneHotMonths = FA.encode(months)
  //  val combinedMatrix1 = oneHotMonths.zip(oneHotDays).map{case (rowA,rowB)=> rowA ++ rowB}
    val combinedMatrix2 = oneHotDays.zip(oneHotHours).map{case (rowA,rowB)=> rowA ++ rowB}
    val combinedMatrix3 = combinedMatrix2.zip(oneHotMinutes).map{case (rowA,rowB)=> rowA ++ rowB}
    val potReal = dataRows.map(_(1)).map(_.toDouble)
    val dataList = combinedMatrix3.zip(potReal).map{case (row, value)=> row:+ value}
    val data: List[Array[Double]] = dataList.map(_.toArray)
//////////////
    val nInputs: Int = data.headOption.map(_.size).getOrElse(0)
    //Número de neuronas de la capa oculta < 2*(numero de neoronas de la capa de entrada)
    println(s"Numero de inputs: $nInputs")
    val nHidden: Int =  (1.9*nInputs).toInt
    println(s"Numero de hiddens: $nHidden")
    //Ejecución de la variante DAPSO del algoritmo
    val trainer = new DAPSO(data,potReal,nInputs,nHidden)
    trainer.inicializar_pesos()
    val start = System.nanoTime()
    trainer.procesar()
    val weights = trainer.get_pesos()
    ///////
    var potPredicha: List[Double] = List()
    //Predicción
    for (i <- 0 until data.length) {
      val pot = FA.forwardProp(data(i), weights, nInputs, nHidden)
      potPredicha = potPredicha :+ pot
    }
    //Resultados
    for ((real, predicho) <- potReal.zip(potPredicha)) {
      println(s"Potencia real: $real - Potencia predicha: $predicho")
    }
    val end = System.nanoTime()
    val tiempo = (end - start) / 1e9
    println(s"Tiempo de ejecucion(s):$tiempo")
    val best_global_fitness = trainer.get_best_global_fitness()
    println(s"mejor fitness global final-> $best_global_fitness")
    val mejor_pos_global = trainer.get_pesos()
    println("mejor posición global final " + mejor_pos_global.mkString(", "))
  }
}
