package DU

import akka.actor.ActorRef

import scala.concurrent.Channel

class Aggregator(private val S: Int, private val srch: Channel[Lote], fitnessEvalActor: ActorRef) {
  private val lote = new Lote(S)

  def recibir(datos: Array[Double]): Unit = {
    if(lote.estaCompleto) {
      srch.write(lote.copiar())
      fitnessEvalActor ! "continue"
      lote.clean()
    }
    lote.agregar(datos)
  }
}