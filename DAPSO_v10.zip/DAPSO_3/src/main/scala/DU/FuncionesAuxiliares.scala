package DU

import org.apache.spark.broadcast.Broadcast

import scala.collection.mutable.ListBuffer
import scala.util.Random

class FuncionesAuxiliares {
  //Genera un uniform entre -a y a
  def Uniform(a: Double, rand: Random): Double = {
    val num = rand.nextDouble() * 2 * a // genera un número aleatorio entre 0.0 y 2a
    val ret = num - a
    ret
  }

  def MSE(y: Array[Double], pred: Broadcast[Array[Double]]): Double = {
    val n = y.length
    if (n != pred.value.length) {
      println("error: datos y predicción de distintos tamaños")
      return -1
    }
    var resultado = 0.0
    for (i <- 0 until n) {
      resultado += math.pow(y(i) - pred.value(i), 2)
    }
    resultado /= n
    resultado
  }



  // Convertir el Array[Array[Double]] a un ListBuffer[Array[Double]]
  def toListBuffer(arrayArray: Array[Array[Double]]): ListBuffer[Array[Double]] ={
    val listBuffer: ListBuffer[Array[Double]] = ListBuffer.empty[Array[Double]]

    // Recorrer cada subarray en el Array[Array[Double]] y convertirlo a un List[Double]
    for (subArray <- arrayArray) {
      val list: List[Double] = subArray.toList
      // Agregar el List[Double] al ListBuffer[Array[Double]]
      listBuffer += list.toArray
    }

    listBuffer
  }



}