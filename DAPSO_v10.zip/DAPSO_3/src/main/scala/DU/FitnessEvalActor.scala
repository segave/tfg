package DU

import scala.concurrent._
import akka.actor.{Actor, ActorSystem, Props}
import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast
import scala.collection.mutable.ListBuffer

import akka.actor.{Actor, ActorRef, Props}
import scala.concurrent.duration._

import akka.actor.{Actor, ActorRef, Props}
import scala.concurrent.duration._

// Definir un actor para evaluar el fitness de forma asíncrona
class FitnessEvalActor(srch: Channel[Lote], fuch: Channel[ListBuffer[Array[Double]]], n: Int, sc: SparkContext, objetivo: Broadcast[Array[Double]]) extends Actor {
  val FE = new FuncionesEval

  def receive: Receive = esperandoInicio

  def esperandoInicio: Receive = {
    case "start" =>
      context.become(procesando)
      self ! "continue" // Enviar mensaje para comenzar a procesar
  }

  def procesando: Receive = {
    case "END" =>
      println("Terminando FitnessEvalActor")
      context.become(esperandoTerminar)
      context.stop(self)
    case "continue" =>
      procesar()
      //self ! "continue" // Enviar mensaje a sí mismo para seguir procesando
  }

  def esperandoTerminar: Receive = {
    case "END" =>
    // El actor ya ha terminado, ignora los mensajes "END" adicionales
    case "continue" =>
      println("FitnessEvalActor ocioso")

  }

  private def procesar(): Unit = {
    println("Evaluando fitness")

    val batch = srch.read
    //val psfu = batch.obtenerLote.map(x => FE.fitnessEval(x, n, objetivo))

    val aux = batch.obtenerLote.toArray
    val RDD = sc.parallelize(aux)
    val psfu_array = RDD.map(x => FE.fitnessEval(x, n, objetivo)).collect()
    val psfu = FE.toListBuffer(psfu_array)

    fuch.write(psfu)
  }
}
