import scala.io.Source
object Programa {
  val FA = new Funciones_Auxiliares

  def main(args: Array[String]): Unit = {
    val fileName = "C:/Users/jorge/Desktop/TFG/REE 2007-2019 David (Preprocesado 2009-2019)/demanda_limpia_final.csv"
    // val fileName = "../training2.csv"//tamaño : 175104 datos
    //val numRowsToKeep: Int = 175104 //Número de filas que queremos mantener
    //val numRowsToKeep: Int = 701107//numero de datos de demanda_limpia_final.csv
    val numRowsToKeep: Int = 1200
    // Número de partículas
    val m = 100
    // Número de iteraciones
    val I = 1000
    var dataRows = Source.fromFile(fileName).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) //filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dates = dataRows.map(_(4))
    val potReal = dataRows.map(_(1)).map(_.toDouble)
    val potProgramada = dataRows.map(_(3)).map(_.toDouble)
    //////
    val (days, hours) = FA.separateDayHourMinuteSecond(dates)
    val daysOfWeek =  FA.convertToDayOfWeek(days)
    var (h,mi) = FA.separateHourMinute(hours)
    val oneHotHours = FA.encode(h)
    val oneHotMinutes = FA.encode(mi)
    val oneHotDays = FA.encode(daysOfWeek)
    val combinedMatrix1 = oneHotHours.zip(oneHotDays).map { case (rowA, rowB) => rowA ++ rowB }
    val combinedMatrix2 = combinedMatrix1.zip(oneHotMinutes).map { case (rowA, rowB) => rowA ++ rowB }
    val dataList = combinedMatrix2.zip(potProgramada).map{case (row, value)=> row:+ value}
    val data: List[Array[Double]] = dataList.map(_.toArray)
    /////
    val separatedData: Array[List[Array[Double]]] = Array.fill(24)(List.empty)
    val separatedPotReal: Array[List[Double]] = Array.fill(24)(List.empty)
    val separatedPotProgramada: Array[List[Double]] = Array.fill(24)(List.empty)
    for ((array, index) <- data.zipWithIndex) {
      for (hour <- 0 until 24) {
        if (array(hour) == 1.0) {
          separatedData(hour) = array.slice(24, array.length) :: separatedData(hour)
          separatedPotProgramada(hour) = potProgramada(index) :: separatedPotProgramada(hour)
          separatedPotReal(hour) = potReal(index) :: separatedPotReal(hour)
        }
      }
    }


///////////
    val nInputs: Int = separatedData(0).headOption.map(_.size).getOrElse(0)
    val nHidden: Int =  (1.9*nInputs).toInt
    val arrayWeights: Array[Array[Double]] = Array.fill(24)(Array.empty[Double])
    //////////
    val start = System.nanoTime()
    //Ejecución de la variante DAPSO del algoritmo
    for (hour<-0 until 24){
      //val trainer = new DAPSO(separatedData(hour), separatedPotReal(hour), nInputs, nHidden, I, m)
      val trainer = new pso_secuencial(separatedData(hour), separatedPotReal(hour), nInputs, nHidden, I, m)
      trainer.inicializar_pesos()
      trainer.procesar()
      arrayWeights(hour) = trainer.get_pesos()
    }

    val end = System.nanoTime()
////////////////
val keyValueMap: Map[Int, String] = Map(
  0 -> "00:00",
  1 -> "01:00",
  2 -> "02:00",
  3 -> "03:00",
  4 -> "04:00",
  5 -> "05:00",
  6 -> "06:00",
  7 -> "07:00",
  8 -> "08:00",
  9 -> "09:00",
  10 -> "10:00",
  11 -> "11:00",
  12 -> "12:00",
  13 -> "13:00",
  14 -> "14:00",
  15 -> "15:00",
  16 -> "16:00",
  17 -> "17:00",
  18 -> "18:00",
  19 -> "19:00",
  20 -> "20:00",
  21 -> "21:00",
  22 -> "22:00",
  23 -> "23:00",
)
    ///////////////
var potPredicha: Array[List[Double]] = Array.fill(24)(List.empty[Double])
    //Predicción
    for (hour <- 0 until 24) {
      for (i <- 0 until separatedData(hour).length) {
        val pot = FA.forwardProp(separatedData(hour)(i), arrayWeights(hour), nInputs, nHidden)
        potPredicha(hour) = potPredicha(hour) :+ pot
      }
   }
    //Resultados
    for (hour <- 0 until 24) {
      println("Resultados para " + keyValueMap(hour))
      for ((real, predicho) <- separatedPotReal(hour).zip(potPredicha(hour))) {
        println(s"Potencia real: $real - Potencia predicha: $predicho")
      }
    }
    val tiempo = (end - start) / 1e9
    println(s"Tiempo de ejecucion(s):$tiempo")



  }
}
