package RED

import scala.concurrent._
//import akka.actor.{Actor, ActorSystem, Props}
import org.apache.spark.SparkContext
//import org.apache.spark.broadcast.Broadcast

import scala.collection.mutable.ListBuffer
//import akka.actor.{Actor, ActorRef, Props}

//import scala.concurrent.duration._
import akka.actor.typed.scaladsl.{ActorContext, Behaviors}
import akka.actor.typed.{ActorRef, ActorSystem, Behavior}
//import org.apache.spark.sql.SparkSession


object FitnessEvalActor {

  import RED.GlobalEvalActor.SystemMessage

  sealed trait MessageToFitnessActor

  final case class ContinueReceivingMessage() extends MessageToFitnessActor

  // Definición de las variables
  val FA = new Funciones_Auxiliares
  private var srch: Channel[Lote] = _
  private var fuch: Channel[ListBuffer[Array[Double]]] = _
  private var x: Array[Array[Double]] = _
  private var y: Array[Double] = _
  private var nInputs: Int = _
  private var nHidden: Int = _
  private var sc: SparkContext = _
  //private var sc: SparkSession = _
  private var umbral: Double = _

  // Método de inicialización
  def initialize(
                  srch: Channel[Lote], fuch: Channel[ListBuffer[Array[Double]]], data: Array[Array[Double]],
                  y: Array[Double], nInputs: Int, nHidden: Int, sc: SparkContext
                ): Unit = {
    FitnessEvalActor.srch = srch
    FitnessEvalActor.fuch = fuch
    FitnessEvalActor.x = data
    FitnessEvalActor.y = y
    FitnessEvalActor.nInputs = nInputs
    FitnessEvalActor.nHidden = nHidden
    FitnessEvalActor.sc = sc

  }

  private def procesar(): Unit = {
    //println("Evaluando fitness")

    val batch = srch.read
    //val psfu = batch.obtenerLote.map(x => FE.fitnessEval(x, n, objetivo))

    val aux = batch.obtenerLote.toArray
    val RDD = sc.parallelize(aux)


    //val psfu_array = RDD.map(part => FA.fitnessEval(x, y, part, nInputs, nHidden)).collect()

    val psfu_array = RDD.mapPartitions(iter => iter.map(part => FA.fitnessEval(x, y, part, nInputs, nHidden))).collect()


    val psfu = FA.toListBuffer(psfu_array)

    fuch.write(psfu)
  }

  def apply(): Behavior[MessageToFitnessActor] = Behaviors.setup {
    context: ActorContext[MessageToFitnessActor] =>
      Behaviors.receiveMessage { message =>
        message match {
          //case ContinueReceivingMessage(sender) =>
          case ContinueReceivingMessage() =>
            procesar()
            Behaviors.same
        }
      }
  }

}
