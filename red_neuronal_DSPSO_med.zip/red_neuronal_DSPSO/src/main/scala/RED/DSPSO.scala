package RED

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.util.CollectionAccumulator
import org.apache.spark.util.DoubleAccumulator
import scala.util.Random
import java.io._
import scala.io.Source

import org.apache.spark.util.CollectionAccumulator

import scala.math._
import java.time._
import java.time.format.DateTimeFormatter
import scala.collection.mutable.ListBuffer
import scala.util.Random

/**
 * @author ${user.name}
 */


object App {

  val conf = new SparkConf()
    .setAppName("PSO Distribuido")
    .setMaster("local[*]")
  val sc = SparkContext.getOrCreate(conf)

  var particulas = Array.empty[Array[Double]]
  var mejor_pos_global = Array.empty[Double]
  var best_global_fitness = Double.MaxValue

  val rand = new Random

  val pos_max = 0.8

  val W = 1.0
  val c_1 = 0.8
  val c_2 = 0.2
  val V_max = 0.6*pos_max

  // Calcula wT*x(i) (Valor predicho para el dato x(i))
  def h(x: Array[Array[Double]], w: Array[Double], i: Int): Double = {
    var sum = 0.0
    for (j <- x(i).indices) {
      sum += x(i)(j) * w(j)
    }
    sum
  }

  def forwardProp(x: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    val z2 = Array.fill(nHidden)(0.0)
    //Paso de capa inicial a oculta
    for (j <- 0 until nHidden) {
      val weights1 = weights.slice(nInputs * j, nInputs * (j + 1))
      var resultado = 0.0
      for (k <- 0 until nInputs) {
        resultado += x(k) * weights1(k)
      }
      z2(j) = resultado
    }
    //paso de la capa de neuronas ocultas a la de salida
    var z3 = 0.0
    val weights2 = weights.slice(nInputs * nHidden, weights.length)
    for (k <- 0 until nHidden) {
      z3 += z2(k) * weights2(k)
    }
    z3 //no se aplica la tanh en la capa de salida
  }

  def MSERed(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    val n_datos = x.length

    for (i <- 0 until n_datos) {
      val pred = forwardProp(x(i), weights, nInputs, nHidden)
      resultado += math.pow(y(i) - pred, 2)
    }
    resultado /= n_datos
    resultado

  }


  def convertToDayOfWeek(dates: List[String]): List[String] = {
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    dates.map { dateStr =>
      val date = LocalDate.parse(dateStr, formatter)
      val dayOfWeek = date.getDayOfWeek.toString
      dayOfWeek
    }
  }

  def separateHourMinute(hourColumn: List[String]): (List[String], List[String]) = {
    val (hours, minutes) = hourColumn.map { hourStr =>
      val parts = hourStr.split(":")
      (parts(0), parts(1))
    }.unzip

    (hours, minutes)
  }

  def separateDayHourMinuteSecond(dates: List[String]): (List[String], List[String]) = {
    val (days, hours) = dates.map { hourStr =>
      val parts = hourStr.split(" ")
      (parts(0), parts(1))
    }.unzip

    (days, hours)
  }

  def encode[T](values: List[T]): List[List[Double]] = {
    val uniqueValues = values.distinct
    val numValues = uniqueValues.length
    val numSamples = values.length

    values.map { value =>
      val index = uniqueValues.indexOf(value)
      List.tabulate(numValues)(i => if (i == index) 1.0 else 0.0)
    }
  }

  def MSEOfDataSeparated(dataSeparated: Array[List[Array[Double]]], valorSeparated: Array[List[Double]], arrayWeights: Array[Array[Double]], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    for (hour <- 0 until 24) {
      val x = dataSeparated(hour).toArray
      val y = valorSeparated(hour).toArray
      val aux: Double = MSERed(x, y, arrayWeights(hour), nInputs, nHidden)
      resultado += aux
    }
    resultado = resultado / 24.0
    resultado
  }

  //Genera un uniform entre -a y a
  def Uniform(a: Double, rand: Random): Double = {
    val num = rand.nextDouble() * 2 * a // genera un número aleatorio entre 0.0 y 2a
    val ret = num - a
    ret
  }

  def fitnessEval(x: Array[Array[Double]], y: Array[Double], particula_pesos: Array[Double], nInputs: Int, nHidden: Int): Array[Double] = {

    val nWeights: Int = nHidden*(nInputs+1)

    if (particula_pesos == null) {
      println("El array de pesos es null")
      return Array.empty[Double]
    }

    val best_fit_local = particula_pesos(3 * nWeights)
    val weights = particula_pesos.slice(0, nWeights)
    val fit = MSERed(x, y, weights, nInputs, nHidden)
    if (fit < best_fit_local) {
      particula_pesos(3 * nWeights) = fit
      for (k <- 0 until nWeights) {
        particula_pesos(2 * nWeights + k) = weights(k)
      }

    }
    particula_pesos
  }

  def posEval(part: Array[Double], mpg: Array[Double], N: Int, rand: Random, W: Double, c_1: Double, c_2: Double, V_max: Double): Array[Double] = {
    // global ind (no es necesario en Scala)
    val velocidades = part.slice(N, 2 * N)
    val mpl = part.slice(2 * N, 3 * N)
    val r_1 = rand.nextDouble()
    val r_2 = rand.nextDouble()
    for (k <- 0 until N) {
      velocidades(k) = W * velocidades(k) + c_1 * r_1 * (mpl(k) - part(k)) + c_2 * r_2 * (mpg(k) - part(k))
      if (velocidades(k) > V_max) {
        velocidades(k) = V_max
      } else if (velocidades(k) < -V_max) {
        velocidades(k) = -V_max
      }
      part(k) = part(k) + velocidades(k)
      if (part(k) > pos_max) {
        part(k) = pos_max
      } else if (part(k) < -pos_max) {
        part(k) = -pos_max
      }
      part(N + k) = velocidades(k)
    }
    part
  }

  def modifyAccum(part: Array[Double], N: Int, local_accum_pos: CollectionAccumulator[Array[Double]], local_accum_fit: CollectionAccumulator[Double]): Unit = {
    local_accum_pos.add((part.slice(2 * N, 3 * N)))
    local_accum_fit.add(part(3 * N))
  }

  def main(args: Array[String]): Unit = {
    val fileName = "C:/Users/jorge/Desktop/TFG/REE 2007-2019 David (Preprocesado 2009-2019)/demanda_limpia_final.csv"

    val numRowsToKeep: Int = 12000 // Número de filas que deseas mantener

    var dataRows = Source.fromFile(fileName).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.take(numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dates = dataRows.map(_(4))
    val potReal = dataRows.map(_(1)).map(_.toDouble)
    val potProgramada = dataRows.map(_(3)).map(_.toDouble)
    //////
    val (days, hours) = separateDayHourMinuteSecond(dates)
    val daysOfWeek = convertToDayOfWeek(days)
    var (h, mi) = separateHourMinute(hours)
    val oneHotHours = encode(h)
    val oneHotMinutes = encode(mi)
    val oneHotDays = encode(daysOfWeek)
    val combinedMatrix1 = oneHotHours.zip(oneHotDays).map { case (rowA, rowB) => rowA ++ rowB }
    val combinedMatrix2 = combinedMatrix1.zip(oneHotMinutes).map { case (rowA, rowB) => rowA ++ rowB }
    val dataList = combinedMatrix2.zip(potProgramada).map { case (row, value) => row :+ value }
    val data: List[Array[Double]] = dataList.map(_.toArray)
    /////
    val separatedData: Array[List[Array[Double]]] = Array.fill(24)(List.empty)
    val separatedPotReal: Array[List[Double]] = Array.fill(24)(List.empty)
    val separatedPotProgramada: Array[List[Double]] = Array.fill(24)(List.empty)
    for ((array, index) <- data.zipWithIndex) {
      for (hour <- 0 until 24) {
        if (array(hour) == 1.0) {
          separatedData(hour) = array.slice(24, array.length) :: separatedData(hour)
          separatedPotProgramada(hour) = potProgramada(index) :: separatedPotProgramada(hour)
          separatedPotReal(hour) = potReal(index) :: separatedPotReal(hour)
        }
      }
    }
    ///////////
    val nInputs: Int = separatedData(0).headOption.map(_.size).getOrElse(0)
    val nHidden: Int = (1.9 * nInputs).toInt
    //val nHidden: Int = 1
    val arrayWeights: Array[Array[Double]] = Array.fill(24)(Array.empty[Double])
    val nWeights: Int = nHidden * (nInputs + 1)
    val n = nWeights
    //////////
    ////////////////
    //Archivos para las gráficas
    val file_1 = new FileWriter(s"errores_iter_part.txt", true)
    val file_2 = new FileWriter(s"tiempo_iters.txt", true)

    val graf_1 = new PrintWriter(file_1)
    val graf_2 = new PrintWriter(file_2)

    //////////////
    val num_iteraciones = List(100)
    val num_particulas = List(1000)

    for (iters <- num_iteraciones) {
      for (parts <- num_particulas) {
        // Número de partículas
        val m = parts
        // Número de iteraciones
        val I = iters

        val existingFile = new FileWriter(s"resultados_ANN_energies_Full$I _$m.txt", true)
        //val existingFile = new FileWriter(s"resultados_sonar_secuencial_$iters _$parts.txt", true)
        val weightsFile = new FileWriter(s"vector_pesos_ANN_energies$I _$m.csv", true)
        val outputFile = new PrintWriter(existingFile)
        val weigthOutput = new PrintWriter(weightsFile)

        val start = System.nanoTime()
        //Ejecución de la variante DAPSO del algoritmo
        for (hour <- 0 until 24) {
          particulas = Array.empty[Array[Double]]
          mejor_pos_global = Array.empty[Double]
          best_global_fitness = Double.MaxValue
          // Convertir las listas a arrays serializables
          val xSer: Array[Array[Double]] = separatedData(hour).toArray
          val ySer: Array[Double] = separatedPotReal(hour).toArray
          // Inicializamos los vectores
          for (i <- 0 until m) {
            //Aquí puede que sea mejor inicializar las últimas posiciones a valores más pequeños
            val posicion = Array.fill(nWeights)(Uniform(2, rand))
            val velocidad = Array.fill(nWeights)(Uniform(2, rand))
            val fit = MSERed(xSer, ySer, posicion, nInputs, nHidden)
            val part_ = posicion ++ velocidad ++ posicion ++ Array(fit)
            if (fit < best_global_fitness) {
              best_global_fitness = fit
              mejor_pos_global = posicion
            }
            particulas = particulas :+ part_
          }
          //procesamos
          var rdd_master = sc.parallelize(particulas)

          for (i <- 0 until I) {
            val local_accum_pos: CollectionAccumulator[Array[Double]] = sc.collectionAccumulator[Array[Double]]("MejorPosLocales")
            //val local_accum_fit: DoubleAccumulator = sc.doubleAccumulator("MiAcumulador")
            val local_accum_fit: CollectionAccumulator[Double] = sc.collectionAccumulator[Double]("MejorFitLocales")
            val rdd_fitness = rdd_master.map(part => fitnessEval(xSer, ySer, part, nInputs, nHidden))
            rdd_fitness.foreach(part => modifyAccum(part, nWeights, local_accum_pos, local_accum_fit))
            val blfs = local_accum_fit.value
            for (j <- 0 until m) {
              val blf = blfs.get(j)
              if (blf < best_global_fitness) {
                best_global_fitness = blf
                mejor_pos_global = local_accum_pos.value.get(j)
              }
            }
            val resultado2 = rdd_fitness.map(part => posEval(part, mejor_pos_global, nWeights, rand, W, c_1, c_2, V_max))
            val resultado_collected = resultado2.collect()
            rdd_master = sc.parallelize(resultado_collected)
          }
          arrayWeights(hour) = mejor_pos_global
        }
        val end = System.nanoTime()
        ////////////////Se guardan los pesos calculados en un archivo
        for (hour <- 0 until 24) {
          val mejor_pos_global = arrayWeights(hour)
          println(s"vector pesos_hora:$hour " + mejor_pos_global.mkString(", "))
          println("tamaño del vector de pesos: " + mejor_pos_global.size)
          weigthOutput.println(mejor_pos_global.mkString(", "))
        }

        ////////////////
        val keyValueMap: Map[Int, String] = Map(
          0 -> "00:00",
          1 -> "01:00",
          2 -> "02:00",
          3 -> "03:00",
          4 -> "04:00",
          5 -> "05:00",
          6 -> "06:00",
          7 -> "07:00",
          8 -> "08:00",
          9 -> "09:00",
          10 -> "10:00",
          11 -> "11:00",
          12 -> "12:00",
          13 -> "13:00",
          14 -> "14:00",
          15 -> "15:00",
          16 -> "16:00",
          17 -> "17:00",
          18 -> "18:00",
          19 -> "19:00",
          20 -> "20:00",
          21 -> "21:00",
          22 -> "22:00",
          23 -> "23:00",
        )
        ////////////////
        var potPredicha: Array[List[Double]] = Array.fill(24)(List.empty[Double])
        //Predicción
        for (hour <- 0 until 24) {
          for (i <- 0 until separatedData(hour).length) {
            val pot = forwardProp(separatedData(hour)(i), arrayWeights(hour), nInputs, nHidden)
            //println("dato: " + separatedData(hour)(i).mkString(", "))
            //println("Pot. pred: " + pot)
            potPredicha(hour) = potPredicha(hour) :+ pot
          }
        }
        //Resultados
        for (hour <- 0 until 24) {
          println("Resultados para " + keyValueMap(hour))
          println("Pesos para " + keyValueMap(hour) + ": " + arrayWeights(hour).mkString(", "))
          for ((real, predicho) <- separatedPotReal(hour).zip(potPredicha(hour))) {
            println(s"Potencia real: $real - Potencia predicha: $predicho")
          }
        }
        val tiempo = (end - start) / 1e9
        println(s"Tiempo de ejecucion(s):$tiempo")

        val error = MSEOfDataSeparated(separatedData, separatedPotReal, arrayWeights, nInputs, nHidden)

        graf_1.println(s"$iters, $parts, $numRowsToKeep, $error")
        graf_2.println(s"$iters, $parts, $numRowsToKeep, $tiempo")

        //comprobación
        /*println("pesos: ")
        for (hour <- 0 until 24) {
          println(arrayWeights(hour).mkString(", "))
        }*/

      }
    }

    graf_1.close()
    graf_2.close()





  }


}


