package DU

import DU.FuncionesAuxiliares
import org.apache.spark.broadcast.Broadcast
import scala.util.Random
import scala.concurrent._
import scala.async.Async._
import scala.util.{Failure, Success}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.collection.mutable.ListBuffer

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.util.CollectionAccumulator
import org.apache.spark.util.DoubleAccumulator

class FuncionesEval {
  val FA = new FuncionesAuxiliares

  def InitParticles(N: Int, M: Int, bgf: Double, mpg: Array[Double], rand: Random, objetivo: Broadcast[Array[Double]]): (Double, Array[Double], Array[Array[Double]]) = {
    var parts_ = Array.empty[Array[Double]]
    var best_global_fitness = bgf
    var mejor_pos_global = mpg


    for (j <- 0 until M) {
      val posicion = Array.fill(N)(FA.Uniform(100, rand))
      val velocidad = Array.fill(N)(FA.Uniform(100, rand))
      val fit = FA.MSE(posicion, objetivo)
      val part_ = posicion ++ velocidad ++ posicion ++ Array(fit)

      //best_local_fitness_arr = best_local_fitness_arr :+ fit
      if (fit < best_global_fitness) {
        best_global_fitness = fit
        //accum.setValue(fit)
        mejor_pos_global = posicion
      }
      parts_ = parts_ :+ part_
    }
    (best_global_fitness, mejor_pos_global, parts_)
  }

  def MSE(y: Array[Double], pred: Broadcast[Array[Double]]): Double = {
    val n = y.length
    if (n != pred.value.length) {
      println("error: datos y predicción de distintos tamaños")
      return -1
    }
    var resultado = 0.0
    for (i <- 0 until n) {
      resultado += math.pow(y(i) - pred.value(i), 2)
    }
    resultado /= n
    resultado
  }

  // Convertir el Array[Array[Double]] a un ListBuffer[Array[Double]]
  def toListBuffer(arrayArray: Array[Array[Double]]): ListBuffer[Array[Double]] = {
    val listBuffer: ListBuffer[Array[Double]] = ListBuffer.empty[Array[Double]]

    // Recorrer cada subarray en el Array[Array[Double]] y convertirlo a un List[Double]
    for (subArray <- arrayArray) {
      val list: List[Double] = subArray.toList
      // Agregar el List[Double] al ListBuffer[Array[Double]]
      listBuffer += list.toArray
    }

    listBuffer
  }

  def fitnessEval(part: Array[Double], N: Int, objetivo: Broadcast[Array[Double]]): Array[Double] = {

    if (part == null) {
      println("El array es null")
      return Array.empty[Double]
    }

    //println(part.length)
    //println(part.mkString(", "))

    val best_fit_local = part(3 * N)
    val filas = part.slice(0, N)
    val fit = MSE(filas, objetivo)
    if (fit < best_fit_local) {
      part(3 * N) = fit
      for (k <- 0 until N) {
        part(2 * N + k) = filas(k)
      }
    }
    part
  }

  def posEval(part: Array[Double], mpg: Array[Double], N: Int, rand: Random, W: Double, c_1: Double, c_2: Double, V_max: Double): Array[Double] = {
    // global ind (no es necesario en Scala)
    val velocidades = part.slice(N, 2 * N)
    val mpl = part.slice(2 * N, 3 * N)
    val r_1 = rand.nextDouble()
    val r_2 = rand.nextDouble()
    for (k <- 0 until N) {
      velocidades(k) = W * velocidades(k) + c_1 * r_1 * (mpl(k) - part(k)) + c_2 * r_2 * (mpg(k) - part(k))
      if (velocidades(k) > V_max) {
        velocidades(k) = V_max
      } else if (velocidades(k) < -V_max) {
        velocidades(k) = -V_max
      }
      part(k) = part(k) + velocidades(k)
      part(N + k) = velocidades(k)
    }
    part
  }

  def parallelFitness(srch: Channel[Lote], n: Int, sc: SparkContext, objetivo: Broadcast[Array[Double]]) = Future {
    var batch = srch.read
    //println("Tamaño del lote: " + batch.obtenerLote.length)
    //println("Relleno del lote: " + batch.obtenerIndex)
    //  println(batch.obtenerLote.mkString(", "))

    val aux = batch.obtenerLote.toArray
    val RDD = sc.parallelize(aux)
    val psfu_array = RDD.map(x => fitnessEval(x, n, objetivo)).collect()
    val psfu = toListBuffer(psfu_array)

    //val psfu = batch.obtenerLote.map(x => fitnessEval(x, n, objetivo))
    //batch = null

    //val psfu = batch.obtenerLote
    //psfu.indices.foreach { i =>
      //val updatedElem = fitnessEval(psfu(i), n, objetivo)
      //psfu.update(i, updatedElem)
    //}



    //RDD.unpersist()
    psfu
  }

  def awaitFitness(srch: Channel[Lote], n: Int, sc: SparkContext, objetivo: Broadcast[Array[Double]]) = async {
    await(parallelFitness(srch, n, sc, objetivo))
  }

}