package DU

import akka.actor.{Actor, ActorRef, ActorSystem, PoisonPill, Props, Terminated}

class ResultsActor extends Actor {
  var start = System.nanoTime()
  var end = System.nanoTime()



  def receive: Receive = {
    case "start" =>
      start = System.nanoTime()

    case "end" =>
      end = System.nanoTime()

      val tiempo = (end - start) / 1e9
      println(s"Tiempo de ejecucion(s): $tiempo")
      self ! PoisonPill

  }

}
