package RED

import scala.util.Random
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.util.CollectionAccumulator
import org.apache.spark.util.DoubleAccumulator


class DSPSO(x: List[Array[Double]], y: List[Double], nInputs: Int, nHidden: Int) {
  val conf = new SparkConf()
    .setAppName("PSO Distribuido")
    .setMaster("local[*]")
  val sc = SparkContext.getOrCreate(conf)

  val FA = new Funciones_Auxiliares

  val nWeights: Int = nInputs * (nHidden + 1)

  // Número dimensiones de los pesos
  val n = nWeights
  // Número de partículas
  val m = 100
  // Número de iteraciones
  val I = 10000

  var particulas = Array.empty[Array[Double]]
  var mejor_pos_global = Array.empty[Double]
  var best_global_fitness = Double.MaxValue

  val rand = new Random

  val W = 1.0
  val c_1 = 0.8
  val c_2 = 0.2
  val V_max = 10.0

  // Convertir las listas a arrays serializables
  val xSer: Array[Array[Double]] = x.toArray
  val ySer: Array[Double] = y.toArray

  // Inicializamos los vectores
  def inicializar_pesos() {

    for (i <- 0 until m) {

      //Aquí puede que sea mejor inicializar las últimas posiciones a valores más pequeños
      val posicion = Array.fill(nWeights)(FA.Uniform(100, rand))
      val velocidad = Array.fill(nWeights)(FA.Uniform(100, rand))
      val fit = FA.MSERed(xSer, ySer, posicion, nInputs, nHidden)
      val part_ = posicion ++ velocidad ++ posicion ++ Array(fit)

      if (fit < best_global_fitness) {
        best_global_fitness = fit
        mejor_pos_global = posicion
      }
      particulas = particulas :+ part_
    }
    //(best_global_fitness, mejor_pos_global, parts_)
  }

  def procesar(): Unit = {

    var rdd_master = sc.parallelize(particulas)

    for (i <- 0 until I) {

      val local_accum_pos: CollectionAccumulator[Array[Double]] = sc.collectionAccumulator[Array[Double]]("MejorPosLocales")
      //val local_accum_fit: DoubleAccumulator = sc.doubleAccumulator("MiAcumulador")
      val local_accum_fit: CollectionAccumulator[Double] = sc.collectionAccumulator[Double]("MejorFitLocales")

      val rdd_fitness = rdd_master.map(part => FA.fitnessEval(xSer, ySer, part, nInputs, nHidden))

      rdd_fitness.foreach(part => FA.modifyAccum(part, nWeights, local_accum_pos, local_accum_fit))

      val blfs = local_accum_fit.value
      for (j <- 0 until m) {
        val blf = blfs.get(j)
        if (blf < best_global_fitness) {
          best_global_fitness = blf
          mejor_pos_global = local_accum_pos.value.get(j)
        }
      }

      val resultado2 = rdd_fitness.map(part => FA.posEval(part, mejor_pos_global, nWeights, rand, W, c_1, c_2, V_max))

      val resultado_collected = resultado2.collect()

      rdd_master = sc.parallelize(resultado_collected)

    }
    println(s"mejor_pos_global-> ${mejor_pos_global.mkString("[", ", ", "]")}")
    println(s"mejor fitness global-> $best_global_fitness")
  }

  def get_pesos(): Array[Double] = {
    mejor_pos_global
  }

}
