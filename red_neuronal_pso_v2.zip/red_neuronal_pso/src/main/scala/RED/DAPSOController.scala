package RED

class DAPSOController(dapso: DAPSO) {
  def recibirResultado(resultado: Array[Double]): Unit = {
    dapso.actualizarResultado(resultado)
  }
}

