package RED

import RED.Funciones_Auxiliares
import scala.io.Source

object Main {

  val FA = new Funciones_Auxiliares

  def main(args: Array[String]): Unit = {
    val fileName = "C:/Users/jorge/Desktop/TFG/REE 2007-2019 David (Preprocesado 2009-2019)/demanda_limpia_final.csv"
    //val csvReader = new CSVReader(fileName)

    //val columns: List[List[String]] = csvReader.readCSV()

    val numRowsToKeep: Int = 500 // Número de filas que deseas mantener

    var dataRows = Source.fromFile(fileName).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.take (numRowsToKeep).toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }

    // Imprimir cada fila y sus columnas
    //for (row <- dataRows) {
      //println(row.mkString(", ")) // Imprime las columnas de la fila separadas por coma
    //}

    // Eliminar la primera fila (cabecera)
    //val dataRows1 = columns.tail

    //quitamos las filas con algún valor vacío
    //val dataRows2 = dataRows1.filter(row => row.forall(value => value.nonEmpty))



    //val dataRows: List[List[String]] = dataRows2.take(numRowsToKeep)

    // Acceder a las columnas individualmente
    var dates = dataRows.map(_(5))
    var hourColumn = dataRows.map(_(0))
    var potProgramadaString = dataRows.map(_(3))
    var potRealString = dataRows.map(_(1))


    println(potProgramadaString.mkString(", "))


    val potProgramada = potProgramadaString.map(_.toDouble)
    val potReal = potRealString.map(_.toDouble)



    var daysOfWeek = FA.convertToDayOfWeek(dates)

    //for ((date, dayOfWeek) <- dates.zip(daysOfWeek)) {
      //println(s"$date: $dayOfWeek")
    //}

    var (hours, minutes) = FA.separateHourMinute(hourColumn)

    val oneHotHours = FA.encode(hours)
    val oneHotMinutes = FA.encode(minutes)
    val oneHotDays = FA.encode(daysOfWeek)

    //Intentamos liberar memoria
    dataRows = null
    potProgramadaString = null
    dates = null
    hourColumn = null
    hours = null
    minutes = null
    daysOfWeek = null


    //oneHotHours.foreach(row => println(row.mkString(", ")))

    val combinedMatrix1 = oneHotDays.zip(oneHotHours).map { case (rowA, rowB) =>
      rowA ++ rowB
    }

    val numRowsCM1: Int = combinedMatrix1.length
    val numRowsOHM: Int = oneHotMinutes.length

    println(s"Número de filas CM1: $numRowsCM1")
    println(s"Número de filas OHM: $numRowsOHM")

    val combinedMatrix2 = combinedMatrix1.zip(oneHotMinutes).map { case (rowA, rowB) =>
      rowA ++ rowB
    }

    val dataList = combinedMatrix2.zip(potProgramada).map { case (row, value) =>
      row :+ value
    }

    val data: List[Array[Double]] = dataList.map(_.toArray)


    // Imprime la matriz combinada
    data.foreach(row => println(row.mkString(", ")))

    //número de características
    val nInputs: Int = data.headOption.map(_.size).getOrElse(0)

    //número de neuronas en la capa oculta
    val nHidden: Int = 4

    //val nWeights: Int = nInputs*(nHidden + 1)

    //var weights: Array[Double] = Array.fill(nWeights - 1)(0.0) :+ 1.0

    //var weights: Array[Double] = Array.fill(nWeights)(0.0)

    //println(s"El número de columnas es: $nInputs")



    //val mse_prueba = FA.MSERed(data, potReal, weights, nInputs, nHidden)

    //println(s"El resultado de la prueba es: $mse_prueba")


    //Ejecución de PSO secuencial
    /*val trainer = new pso_secuencial(data, potReal, nInputs, nHidden)

    trainer.inicializar_pesos()

    trainer.procesar()

    val weights = trainer.get_pesos()*/

    //Ejecución de DSPSO
    /*val trainer = new DSPSO(data, potReal, nInputs, nHidden)

    trainer.inicializar_pesos()

    trainer.procesar()

    val weights = trainer.get_pesos()*/

    //Ejecución de DAPSO
    val trainer = new DAPSO(data, potReal, nInputs, nHidden)

    trainer.inicializar_pesos()

    trainer.procesar()

    val weights = trainer.get_pesos()



    var potPredicha: List[Double] = List()
    for (i <- 0 until data.length) {
      val pot = FA.forwardProp(data(i), weights, nInputs, nHidden)

      potPredicha = potPredicha :+ pot
    }

    for ((real, predicho) <- potReal.zip(potPredicha)) {
      println(s"Potencia real: $real - Potencia predicha: $predicho")
    }



  }
}
